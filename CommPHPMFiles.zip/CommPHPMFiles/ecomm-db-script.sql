﻿
DROP TABLE IF EXISTS `category_master`;
CREATE TABLE `category_master` (
  `cat_id` int(11) NOT NULL,
  `cat_type` varchar(50) NOT NULL,
  KEY `Index_1` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category_master` (`cat_id`,`cat_type`) VALUES 
 (1,'Cables'),
 (2,'Cameras'),
 (3,'Input Devices'),
 (4,'Memory'),
 (5,'Monitors'),
 (6,'Printers'),
 (7,'Scanners'),
 (8,'Server Accessories'),
 (9,'Wireless'),
 (10,'Sports');


DROP TABLE IF EXISTS `checkout_master`;
CREATE TABLE `checkout_master` (
  `checkout_id` int(11) NOT NULL,
  `checkout_cust_id` int(11) default NULL,
  `checkout_date` date default NULL,
  `checkout_amount` int(11) default NULL,
  `checkout_payment_success` int(11) default NULL,
  `checout_transaction_id` int(11) default NULL,
  PRIMARY KEY  (`checkout_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `checkout_master` (`checkout_id`,`checkout_cust_id`,`checkout_date`,`checkout_amount`,`checkout_payment_success`,`checout_transaction_id`) VALUES 
 (1,1,'2009-01-01',1000,1,101),
 (2,1,'2009-02-01',6000,1,102),
 (3,1,'2009-03-12',24628,1,103),
 (4,2,'2009-03-12',28300,1,104),
 (5,2,'2009-03-12',1650,1,105),
 (6,3,'2009-03-12',12850,1,106),
 (7,3,'2009-03-14',330,1,107),
 (8,4,'2009-03-14',6466,1,108),
 (9,1,'2009-05-10',48900,1,109),
 (10,10,'2011-05-01',7750,1,110),
 (11,1,'2013-07-12',66900,1,26),
 (12,1,'2013-07-12',66900,1,27),
 (13,1,'2013-07-12',66900,1,28),
 (14,1,'2013-07-12',66900,1,29),
 (15,1,'2013-07-12',66900,1,29),
 (16,1,'2013-07-12',66900,1,29),
 (17,1,'2013-07-12',66900,1,30),
 (18,1,'2013-07-16',7350,1,29),
 (19,1,'2013-07-16',2940,1,31),
 (20,1,'2013-07-16',16500,1,33);




DROP TABLE IF EXISTS `checkout_tranasation`;
CREATE TABLE `checkout_tranasation` (
  `ct_id` int(11) NOT NULL,
  `ct_checkout_id` int(11) default NULL,
  `ct_product_id` int(11) default NULL,
  `ct_quantity` int(11) default NULL,
  `ct_rate` int(11) default NULL,
  PRIMARY KEY  (`ct_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `checkout_tranasation` (`ct_id`,`ct_checkout_id`,`ct_product_id`,`ct_quantity`,`ct_rate`) VALUES 
 (1,1,1,1,10000),
 (2,1,1,2,250),
 (3,2,3,1,500),
 (4,2,5,2,350),
 (5,2,12,1,4000),
 (6,3,1,10,110),
 (7,3,2,100,160),
 (8,3,2,1,160),
 (9,3,5,2,717),
 (10,3,13,2,2250),
 (11,3,5,2,717),
 (12,4,7,2,7750),
 (13,4,8,1,12800),
 (14,5,10,3,550),
 (15,6,11,5,770),
 (16,6,13,4,2250),
 (17,7,1,3,110),
 (18,8,5,2,717),
 (19,8,3,2,2516),
 (20,9,2,2,160),
 (21,9,3,5,2516),
 (22,9,8,1,12800),
 (23,9,11,10,770),
 (24,9,7,2,7750),
 (25,10,7,1,7750),
 (26,11,12,2,1300),
 (27,12,12,2,1300),
 (28,13,12,2,1300),
 (30,18,46,5,1470),
 (32,19,46,2,1470),
 (34,20,36,1,16500);




DROP TABLE IF EXISTS `contact_us`;
CREATE TABLE `contact_us` (
  `cu_id` int(11) NOT NULL auto_increment,
  `cu_name` varchar(100) NOT NULL,
  `cu_emailid` varchar(100) NOT NULL,
  `cu_subject` varchar(100) NOT NULL,
  `cu_comment` varchar(50) NOT NULL,
  PRIMARY KEY  (`cu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `contact_us` (`cu_id`,`cu_name`,`cu_emailid`,`cu_subject`,`cu_comment`) VALUES 
 (1,'asdasd','asdas@asdfasf.com','asdas','dasdasd'),
 (2,'ajprofessionals','ajprofessionals@gmail.com','ssssss','');

DROP TABLE IF EXISTS `customer_master`;
CREATE TABLE `customer_master` (
  `cust_id` int(11) NOT NULL,
  `cust_email_id` varchar(50) default NULL,
  `cust_password` varchar(50) default NULL,
  `cust_name` varchar(50) default NULL,
  `cust_join_date` date default NULL,
  `cust_last_login_date1` date default NULL,
  `cust_last_login_date2` date default NULL,
  `cust_pass_chg_date` date default NULL,
  `cust_address` varchar(250) default NULL,
  `cust_city` varchar(50) default NULL,
  `cust_state` varchar(50) default NULL,
  `cust_postal_code` varchar(50) default NULL,
  `cust_contact_no` varchar(50) default NULL,
  PRIMARY KEY  (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `customer_master` (`cust_id`,`cust_email_id`,`cust_password`,`cust_name`,`cust_join_date`,`cust_last_login_date1`,`cust_last_login_date2`,`cust_pass_chg_date`,`cust_address`,`cust_city`,`cust_state`,`cust_postal_code`,`cust_contact_no`) VALUES 
 (1,'atanu.maity@rediffmail.com','3','Atanu Maity','2009-01-01','2010-03-15','2010-03-15',NULL,'mumbai11','','','',''),
 (2,'abc@abc.com','1','qeqweqwe','2009-03-12','2009-03-12','2009-03-12',NULL,'1wewe','1','1','1','q'),
 (3,'MOU@HOTMAIL.COM','1','Mou','2009-03-12','2009-03-14','2009-03-14',NULL,'B-8, Shanti Park, Fort, Central Park','Mumbai','Maharshtra','400001','32902020'),
 (4,'atanu.maity@gmail.com','1','Atanu Maity','2009-03-14','2009-03-14','2009-03-14',NULL,'10/B, SB Road, Andheri -E, Mumbai','Mumbai','Maharashtra','400001','20005666'),
 (5,'a@a.com','1','A','2009-05-03','2009-05-03','2009-05-03',NULL,'a','c','p','p','ccc'),
 (6,'p@p.com','p','p','2009-05-03',NULL,NULL,NULL,'p','p','p','p','p'),
 (7,'s','s','s','2009-05-03',NULL,NULL,NULL,'s','s','s','s','s'),
 (8,'m@m.com','m','m','2009-05-03',NULL,NULL,NULL,'m','m','m','m','m'),
 (9,'x','x','x','2009-05-03',NULL,NULL,NULL,'x','x','x','x','x'),
 (10,'x@x.com','1','A','2011-05-01','2011-05-01','2011-05-01',NULL,'Mumbai','','','','9999999'),
 (11,'abcd@abcd.com','1','ABCD','2011-10-10','2011-10-10',NULL,NULL,'','','','',''),
 (12,'','','','2013-07-07',NULL,NULL,NULL,'','','','',''),
 (13,'sdfsdf','sdfsdfs','sdfsdf','2013-07-07',NULL,NULL,NULL,'sdfsdf','sdfsdf','dsfsdf','sdfsdf','sdfsd'),
 (14,'mou.adi082010@gmail.com','1','Mousumi','2013-07-07',NULL,NULL,NULL,'Mumbai','Mumbai','Maharashtra','400107','9999999999');


DROP TABLE IF EXISTS `customer_shipping`;
CREATE TABLE `customer_shipping` (
  `mb_id` int(11) NOT NULL,
  `mb_cust_id` int(11) NOT NULL,
  `mb_address` varchar(250) default NULL,
  `mb_city` varchar(50) default NULL,
  `mb_state` varchar(50) default NULL,
  `mb_postal_code` varchar(50) default NULL,
  `mb_contact_no` varchar(50) default NULL,
  PRIMARY KEY  (`mb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `product_master`;
CREATE TABLE `product_master` (
  `prod_id` int(11) NOT NULL,
  `prod_cat_id` int(11) default NULL,
  `prod_vendor_id` int(11) default NULL,
  `prod_name` varchar(150) character set utf8 default NULL,
  `prod_description` varchar(500) default NULL,
  `prod_price` int(11) default NULL,
  `prod_tax` int(11) default NULL,
  `prod_create_by` int(11) default NULL,
  `prod_create_date` date default NULL,
  `prod_image` varchar(50) default NULL,
  PRIMARY KEY  (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product_master` (`prod_id`,`prod_cat_id`,`prod_vendor_id`,`prod_name`,`prod_description`,`prod_price`,`prod_tax`,`prod_create_by`,`prod_create_date`,`prod_image`) VALUES 
 (1,1,1,'RJ 45 LAN Cable','RJ 45 LAN Cable, Length = 15m, Connect your PC to ASDL Router Modem. Connect PC to hubs or switches. Ideal Connection between xbox and router. Factory fitted RJ45 plugs and Heavy Duty Boots / Cat5e UTP Quality Moulded Cable',100,10,1,'2009-01-01','1.jpg'),
 (2,1,2,'CAT 5 LAN Cable','Cat 5e Ethernet Cable with RJ45 connections. 5 meter cable straight through cable. Suitable for connecting PC, Xbox, PS3 to cable modem or broadband router. Please note colour of cable may vary. Also know as LAN cable, RJ45 cable, network cable',150,10,1,'2009-01-01','2.jpg'),
 (3,1,1,'CPU Fan Adapter Cable','The StarTech.com 6\" 3-pin to Large Internal Power CPU Fan Adapter Cable allows a fan with a TX3 motherboard connector to draw power from a standard LP4 power supply connector.',2501,15,1,'2009-01-01','3.jpg'),
 (4,1,1,' BT Extension Telephone Cable','Telephone Cable,  BT Extension Cable, 10 Mtrs, White',50,2,1,'2009-01-01','4.jpg'),
 (5,2,2,'5.0 Mega pixels Web Cam','Up to 5.0 Mega pixels resolution. Moving Image Capture: 2M Mega Pixels. Still Image Capture: 5M Mega Pixels. Lens:high quality 5 layers glass lens\r\nWith Night Version, 6 Emitters on both sides of the Len. USB 2.0. No driver need. Display:640*480 352*288 320*240 176*144 160*120. VGA 640*480 AT 30 fps. lens focus:F6.0mm. Focus ranger:from 20mm to limitless far. white balance:Automatic /manual Expose control :Automatic/manual. Flash control:50HZ or 60HZ',700,17,1,'2009-01-01','5.jpg'),
 (6,2,2,'1.3 Mega pixels Web Cam','Manufacturer: LogiLink. Connection: USB 2.0. CMOS: 1.3 Million Pixels. Resolution: 1280 x 960. Frame Rate: 30 fps. Microphone: Internal',500,15,1,'2009-01-01','6.jpg'),
 (7,2,2,'7.2 MP Sony Cybershot Digital Camera','7.2 effective megapixels resolution for clear enlargements up to A3 size. 4x optical zoom Carl Zeiss Vario-Tessar lens. Enhanced Face Detection with high-speed subject tracking for clearer portraits\r\nLarge 2.5-inch LCD. HD Output compatible with PhotoTV HD displays for optimised still images on BRAVIA TV. BIONZ processor for enhanced image quality and fast response. High Sensitivity ISO 3200 for clearer handheld shooting in low light',7500,250,1,'2009-01-01','7.jpg'),
 (8,2,2,'10 MP Nikon DX format SLR','Nikon DX format CCD 10.2 MP. 3-area AF system. 3D Colour Matrix Metering II system. 2.5 inch screen. 3.0 fps continuous shooting. Near instant power-up (0.18 sec.). Compact, lightweight body. User-friendly design. In-camera image editing functions',12000,800,1,'2009-01-01','8.jpg'),
 (9,3,1,'Microsoft Comfort Curve Keyboard 2000','Sleek, compact design with low-profile keys. Curved keyboard design delivers more comfort. Water-resistant. Easy setup and use. Convenient Hot Keys. One-touch control of music, video and more. Back and Forward keys',350,10,1,'2009-01-01','9.jpg'),
 (10,3,1,'3 Button USB Mouse 520 DPI','These retail packaged USB mice are compatible with Windows 95, 98, SE, NT, 2000, Me & XP. They are compatible with all major application software and have 520 / 800 DPI resolution and fast tracking speed with opto-mechanical encoder. Now discontinued, so grab a bargain while stocks last!',500,50,1,'2009-01-01','10.jpg'),
 (11,3,1,'Logitech OEM RX250 Optical Mouse Black','The RX250 Optical Mouse, with its classic renowned design, offers consistent optical tracking performance with additional features truly enhancing the user experience. ',700,70,1,'2009-01-01','11.jpg'),
 (12,4,1,'Kingston - Memory - 512 MB RAM','Kingston is the world\'s largest independent memory manufacturer. In today\'s performance-driven environment, memory upgrades provide an easy, economical alternative to increase system performance. Every memory product Kingston offers is designed to help you get maximum performance at the best price to you.This memory is intended for HP/Compaq Presario SA4000T (CTO) and HP/Compaq Workstation xw4200',1200,100,1,'2009-01-01','12.jpg'),
 (13,4,1,'Transend 4Gb150X Secure Digital SD Card','Transcend\'s 150X SD Cards achieve outstanding data transfer rates and ultra performance. It\'s the best choice for your digital camera and other handheld device. Transcend manufactures all of its SD cards using brand name MLC (Multi-Level Cell) NAND Flash chips and premium quality components to ensure robust, long-life durability and performance.',2000,250,1,'2009-01-01','13.jpg'),
 (14,1,1,'RiteAV - Cat5e Network Ethernet Cable 100ft.','Category 5e Network (Ethernet) Cable, Blue, 100 ft',500,12,1,'2009-01-01','14.jpg'),
 (15,2,2,'Canon PowerShot SD1100IS 8MP Digital Camera ','Color communicates. It introduces you before you say a word, making the Canon PowerShot SD1100 IS Digital Elph the ultimate image-maker. Five fashion-forward hues expressed in pure aluminum add a new burst of excitement to Canon’s Perpetual Curve design. Of course, a camera that brings out the best in you also delivers Canon’s most advanced technology features. Call it style with substance, for a new level of picture taking pleasure.',15000,750,1,'2009-01-01','15.jpg'),
 (16,3,1,'Logitech Illuminated Ultrathin Keyboard','Bright, laser-etched, backlit keys that let you type easily--even in the dark. Cutting-edge, ultra-thin profile. (9.3 mm) that adds an elegant touch to any desk. PerfectStroke key system for typing that\'s silent, natural and fluid. Sleek, minimalist design for the ideal combination of form and function. Soft-touch palm rest and full-size key layout for enhanced comfort ',2500,200,1,'2009-01-01','16.jpg'),
 (17,3,1,'Logitech G19 Gaming Keyboard\r\n','Giving you an arsenal of advanced gaming technology, the Logitech G19 gaming keyboard is the first Logitech keyboard to feature a color GamePanel LCD. The tiltable, 320-by-240-pixel display provides valuable in-game information for over sixty games, including World of Warcraft (requires installation of included Logitech GamePanel software).',3000,275,1,'2009-01-01','17.jpg'),
 (18,4,1,'SANDISK Cruzer Micro U3 4GB USB Flash Drive ','SanDisk is one of the top manufacturers of flash drives, pen drive, and thumb drive. Sandisk Cruzer Micro U3 4GB USB flash drive was now introduced to the current flash memory market and it was quickly become one of the fast growing portable storage devic \r\n',700,50,1,'2009-01-01','18.jpg'),
 (19,4,1,'Sandisk SDSDPH-1024-901 1 GB','SanDisk\'s Ultra II is the high-performance digital memory solution for the serious photographers. This family of outstanding flash cards provides the durability and high-speed quality needed for advanced amateur photographers and photo enthusiasts. SanDisk\'s newest addition to this family is the innovative Ultra II SD Plus. The ground-breaking card provides the unique capability of utilizing your SD card in a USB port.',1250,125,1,'2009-01-01','19.jpg'),
 (20,4,1,'Kingston 1 GB Secure Digital Flash Card ','The Kingston Secure Digital (SD) memory card combines massive storage capacity, blazing data transfer rates, and ironclad security in a memory card no bigger than a postage stamp. With an excellent price-to-performance value, this card is an ideal expansion option for the smallest of devices, including MP3 players, digital cameras, PDAs, smartphones, and more.',2000,150,1,'2009-01-01','20.jpg'),
 (21,5,1,'Dell 19\" CRT Monitor','This Dell 19-inch monitor is a solid, inexpensive entry into the CRT world. It delivers a 0.26-millimeter dot pitch and maximum 1,600 x 1,200 resolution, providing amply sharp and clear images. The viewable screen size is a substantial 18 diagonal inches, so you don\'t have to strain your eyes when you use your computer. The screen also has a special antiglare and antistatic coating to increase visibility. The monitor is completely plug-and-play ready.',7000,350,1,'2009-01-01','21.jpg'),
 (22,5,1,'NEC MultiSync FE2111SB 21\" CRT Monitor ','Make a bright investment in performance with the 22-inch (20-inch viewable) NEC MultiSync FE2111SB, a flat-screen CRT monitor boasting superior image quality and unprecedented brightness. This model\'s cabinet, which features a user-friendly design with recessed cable connections, is available in white or black to match your desktop system or laptop. \r\n',6000,300,1,'2009-01-01','22.jpg'),
 (23,5,1,'Acer V173b 17-Inch LCD Monitor','Size/Type: 17\" TFT LCD. Maximum Resolution: 1280 x 1024 Maximum Refresh Rate: 75Hz Dynamic Contrast Ratio: 2000:1 Response Time: 5ms',8000,400,1,'2009-01-01','23.jpg'),
 (24,5,1,'HP W2207 22-inch Widescreen Flat Panel LCD Monitor','HP W2207 22 In Widescreen Flat Panel LCD Monitor. The HP w2207 with BrightView panel provides an elegant flat panel monitor with a wide view for work or play. The HP w2207 provides a BrightView widescreen panel for for brilliant picture quality. Dual inputs support true digital /DVI D/ and traditional analog /VGA/ signals. HDCP enabled for optimum viewing of High Definition content /High Bandwidth Digital Content Protection.',1500,750,1,'2009-01-01','24.jpg'),
 (25,5,1,'HP W2207H 22-inch Widescreen LCD Monitor','The HP w2207 with BrightView panel provides an elegant flat panel monitor with a wide view for work or play. Adjust the tilt, height and switch between landscape or portrait orientation of the display to suit your needs. ',1800,680,1,'2009-01-01','25.jpg'),
 (26,5,1,'Samsung SyncMaster 2253BW 22-inch LCD Monitor','Immerse yourself in your digital entertainment. With an ultra-fast 2 ms response time, you\'ll experience virtually no blurring when watching movies or playing video games. Add to that an 8000:1 contrast ratio for superior quality color and a 1680x1050 resolution that lets you see the sharpest details',2200,1200,1,'2009-01-11','26.jpg'),
 (27,6,1,'HP Deskjet F4280 All-in-One Printer, Scanner','The HP Deskjet F4280 All-in-One Printer is designed for cost-conscious users who want to print, copy, and scan with one affordable and dependable multi-function device. With a stylish, contemporary aesthetic that\'s certain to look good in any home office',7000,350,1,'2009-01-01','27.jpg'),
 (28,6,1,'Canon Pixma iP2600 Photo Inkjet Printer','This compact photo printer delivers true ease of use and amazing results. Its patented print head technology lets you produce beautiful, long-lasting photos with borderless edges, from credit- card size, up to 8.5x11, and with resolution up to 4800 x 1200 color dpi. ',12500,1000,1,'2009-01-01','28.jpg'),
 (29,6,1,'Epson WorkForce 600','Show the world what your business is made of with the Epson WorkForce 600 All-In-One Printer, engineered for the small business and home office. Get laser quality output at laser fast speeds. Make your business look its best with brilliant color output. It includes the ability to wirelessly print and archive critical documents',25000,2000,1,'2009-01-01','29.jpg'),
 (30,6,2,'HP J3680 Officejet','Get your office under control with the HP J3680 Officejet All-in-One Printer, scanner, copier, and fax machine. This multifunction color printer produces laser-quality text and colorful documents fast and efficiently.',5500,500,1,'2009-01-01','30.jpg'),
 (31,6,2,'Canon Pixma MP530 ','The Canon Pixma MP530 is a versatile all-in-one unit combines printing, scanning, faxing, and copying capabilities in one compact, space-saving device that delivers fast, professional results job after job.',6000,575,1,'2009-01-01','31.jpg'),
 (32,7,1,'Canon CanoScan 4400F Color Image Scanner ','Ready to produce high-resolution scans of photos, documents, even 35mm film and slides? With the CanoScan 4400F Color Image Scanner it’s easy. Seven buttons automate the entire scanning process, so it\'s simple to scan, copy and create e-mails and multi-page PDFs.',3500,300,1,'2009-01-01','32.jpg'),
 (33,7,1,'Epson Perfection V300','Scan film, photos and 3D objects with amazing clarity and detail - the value-priced Epson Perfection V300 Photo makes it easier than ever with 4800 dpi optical resolution and a host of family-friendly features. Use the built-in Transparency Unit to scan up to 6 negative frames or 4 slides at one time.',4000,375,1,'2009-01-01','33.jpg'),
 (34,7,1,'Pentax DSmobile 600 Scanner','Weighing in at less than 12 ounces and measuring just 11 inches wide, the Pentax DSmobile lets you carry around all you need to scan everything from a business card to an 8.5 by 14 inch document. The scanner draws power from its USB interface so no clunky AC adapter is needed.',5000,450,1,'2009-01-01','34.jpg'),
 (35,7,1,'Fujitsu Scansnap S300','Take document scanning to a whole new level with the Fujitsu ScanSnap S300 Color Mobile Scanner. Whether you\'re at home digitizing receipts, bank statements or term papers, or at the office capturing mission critical documents for a business trip, ScanSnap takes scanning beyond the desktop and into your world.',10000,570,1,'2009-01-01','35.jpg'),
 (36,7,2,'Fujitsu FI-5120C Scanner\r\n','The Fujitsu fi-5120C scanner offers outstanding price/performance value in a compact footprint making it well suited for the front-office environment. It scans in color, grayscale and monochrome at duplex speeds up to 50 ipm and features 600 dpi optical resolution for incredible image quality. ',15000,1500,1,'2009-01-01','36.jpg'),
 (37,8,1,'5U Server Tower Case ','Enlight\'s computer enclosures are quickly becoming the market leaders. The company\'s line of standard enclosures is anything but standard. Every case and chassis is designed for easy manufacturability with unique patented features. ',5000,500,1,'2009-01-01','37.jpg'),
 (38,8,1,'Supermicro SC513L-420 ','Superior design and uncompromising quality control enabled Supermicro to offer high-end products with unsurpassable performance to the market since its founding in 1993. With this unbeatable track record, Supermicro has earned a reputation as a manufacturing leader in the industry. ',40000,2500,1,'2009-01-01','38.jpg'),
 (39,8,1,'HP EX487 MediaSmart Home Server','Automatically back up and protect your digital memories, centralize your media and content for sharing with friends and family, and enjoy your digital media while at home or away with the HP EX487 MediaSmart Home Server. Based on the Microsoft Windows Home Server platform',45000,3000,1,'2009-01-01','39.jpg'),
 (40,8,1,'Antec ATLAS Black Server Case ','The new, smaller sibling to the Titan 550, the Atlas case continues to meet the needs of today\'s server and workstation markets. Front accessible HDD installation, a 120mm TriCool¿ exhaust fan & two front 92mm fan mounts and a 550W power supply make building',2500,200,1,'2009-01-01','40.jpg'),
 (41,8,2,'Linksys Network Storage System','Introducing the new Linksys Network Storage System. Now you can quickly and easily add storage capacity to your network with greater ease. Organize your life into one media library. Rip your music and movie library and store them digitally. ',15000,750,1,'2009-01-01','41.jpg'),
 (42,9,2,'Linksys WUSB54G Wireless-G USB Adapter','Connect your USB-equipped desktop or notebook computer to a wireless network at incredible speeds with the Linksys Wireless-G USB Network Adapter. By incorporating two new, blazing fast technologies -- USB 2.0 and Wireless-G -- the Adapter delivers data rates up to 54 Mbps (5 times as fast as 802.11b), without the trouble of opening up the case of your desktop computer.',3000,300,1,'2009-01-01','42.jpg'),
 (43,9,2,'802.11g 54Mbps Wireless LAN PCI Adapter','1.Complies with 2.4GHz IEEE802.1g/b Standard.2.Complies with PCI 2.2 Standard .3.Data Rate up to 54Mbps.4.Data Rate up to 54Mbps, auto fallback under noisy environment .5.Support WPA and 64/128-bit WEP Encryption .6.Low Power Consumption. ',750,70,1,'2009-01-01','43.jpg'),
 (44,9,2,'BlueTooth Wireless USB','Wireless computer-to-computer communications USB adapter, conforming to Bluetooth Ver. 1.1 abd 1.2 Enables Plug & Play wireless communications on Desktops, Laptops, and etc. built-in USB. Features BlueTooth Class I 328 feet range (100 meters) Up to 723Kbps Internet Access sharing.',3000,350,1,'2009-01-01','44.jpg'),
 (45,9,2,'Bluetooth Ear Clip Headset','Enjoy hours of cord-free conversations with a Bluetooth headset... then just change the battery! It holds a single AAA battery so you never have to deal with a specific AC charger. Requires AAA battery, not included, and Bluetooth-compatible mobile phone.',5000,500,1,'2009-01-01','45.jpg'),
 (46,9,2,'Sabrent PCI-G802 Wireless LAN 802.11g PCI Network ','The PCI Wirelress LAN adapter gives you the flexibility to install the PC in the most convenient location available, without the cost of running network cables. This Wireless PCI 802.11G adapter enables 54 Mbps wireless internet access to your computer. It simply plugs into the PCI port of your PC. ',1350,120,1,'2009-01-01','46.jpg'),
 (47,5,1,'ViewSonic VA1926w 19-inch Wide LCD Monitor','ViewSonic’s 19\" VA1926w LCD brings new clarity to budget-pricedwidescreen displays. Prepare to be amazed at this display’s extreme clarity, amazing color, and stunning brightness. With 2000:1 dynamic constrast ratio (typical), 1440 x 900 resolution and fast ClearMotiv 5ms video response, graphics videos and spreadsheets have never been clearer.',10000,550,1,'2009-01-01','47.jpg');

DROP TABLE IF EXISTS `shipping_master`;
CREATE TABLE `shipping_master` (
  `ship_id` int(11) NOT NULL default '0',
  `ship_vendor_id` int(11) default NULL,
  `ship_checkout_id` int(11) default NULL,
  `ship_cust_id` int(11) default NULL,
  `ship_address1` varchar(50) character set utf8 default NULL,
  `ship_address2` varchar(50) character set utf8 default NULL,
  `ship_city` varchar(50) character set utf8 default NULL,
  `ship_state` varchar(50) character set utf8 default NULL,
  `ship_postal_code` varchar(50) character set utf8 default NULL,
  `ship_contct_no` varchar(50) character set utf8 default NULL,
  PRIMARY KEY  (`ship_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `shipping_transcation`;
CREATE TABLE `shipping_transcation` (
  `st_id` int(11) NOT NULL default '0',
  `st_ship_id` int(11) default NULL,
  `st_prod_id` int(11) default NULL,
  `st_quantity` int(11) default NULL,
  PRIMARY KEY  (`st_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE `shopping_cart` (
  `sc_id` int(11) NOT NULL,
  `sc_cust_id` int(11) NOT NULL,
  `sc_date` datetime NOT NULL,
  `sc_product_id` int(11) NOT NULL,
  `sc_quantity` int(11) NOT NULL,
  `sc_check_out` int(11) NOT NULL,
  PRIMARY KEY  (`sc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `shopping_cart` (`sc_id`,`sc_cust_id`,`sc_date`,`sc_product_id`,`sc_quantity`,`sc_check_out`) VALUES 
 (1,1,'2009-01-01 00:00:00',1,10,1),
 (2,1,'2009-01-01 00:00:00',2,100,1),
 (4,1,'2009-03-12 00:13:22',2,1,1),
 (5,1,'2009-03-12 00:15:08',5,2,1),
 (6,1,'2009-03-12 00:15:29',13,2,1),
 (7,1,'2009-03-12 00:16:15',5,2,1),
 (8,2,'2009-03-12 01:59:00',7,2,1),
 (9,2,'2009-03-12 01:59:16',8,1,1),
 (10,2,'2009-03-12 02:00:00',10,3,1),
 (11,3,'2009-03-12 02:07:19',11,5,1),
 (13,3,'2009-03-12 02:08:25',13,4,1),
 (14,3,'2009-03-14 23:27:20',1,3,1),
 (15,4,'2009-03-14 23:39:37',5,2,1),
 (16,4,'2009-03-14 23:40:20',3,2,1),
 (17,1,'2009-03-15 14:40:43',2,2,1),
 (18,1,'2009-03-15 14:40:50',3,5,1),
 (19,1,'2009-03-15 14:40:59',8,1,1),
 (20,1,'2009-03-15 14:41:09',11,10,1),
 (21,1,'2009-03-15 14:41:17',7,2,1),
 (22,5,'2009-05-03 01:36:17',7,1,0),
 (23,5,'2009-05-03 01:36:55',6,2,0),
 (24,1,'2009-11-11 20:52:09',12,2,1),
 (25,1,'2009-11-11 20:52:55',8,4,1),
 (27,10,'2011-05-01 15:05:39',7,1,1),
 (28,10,'2011-05-01 15:07:04',9,1,0),
 (29,11,'2011-10-10 21:44:37',21,2,0),
 (30,1,'2013-07-11 22:13:39',17,4,1),
 (31,1,'2013-07-15 23:07:54',46,5,1),
 (32,1,'2013-07-16 00:49:53',46,2,1),
 (33,1,'2013-07-16 00:53:07',36,1,1);


DROP TABLE IF EXISTS `user_master`;
CREATE TABLE `user_master` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) character set utf8 default NULL,
  `user_password` varchar(50) character set utf8 default NULL,
  `user_type` varchar(50) character set utf8 default NULL,
  `user_create_date` date default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `user_master` (`user_id`,`user_name`,`user_password`,`user_type`,`user_create_date`) VALUES 
 (1,'ADMIN','1','ADMIN','2009-01-01'),
 (2,'AJAY KUMAR 1','123456','USER','2009-03-14'),
 (3,'RAJESH YADAV','123456','ADMIN','2009-03-14'),
 (4,'SANJAY SHARMA','123456','USER','2009-03-14'),
 (5,'SUNNY','123456','ADMIN','2011-05-01'),
 (6,'RAVI','123456','admin','2013-07-20');
/*!40000 ALTER TABLE `user_master` ENABLE KEYS */;


--
-- Definition of table `vendor_master`
--

DROP TABLE IF EXISTS `vendor_master`;
CREATE TABLE `vendor_master` (
  `vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(50) character set utf8 default NULL,
  `vendor_address` varchar(150) character set utf8 default NULL,
  `vendor_city` varchar(50) character set utf8 default NULL,
  `vendor_state` varchar(50) character set utf8 default NULL,
  `vendor_postal_code` varchar(50) character set utf8 default NULL,
  `vendor_contact_no` varchar(50) character set utf8 default NULL,
  `vendor_email` varchar(50) character set utf8 default NULL,
  `vendor_create_by` int(11) default NULL,
  `vendor_create_date` date default NULL,
  PRIMARY KEY  (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `vendor_master` (`vendor_id`,`vendor_name`,`vendor_address`,`vendor_city`,`vendor_state`,`vendor_postal_code`,`vendor_contact_no`,`vendor_email`,`vendor_create_by`,`vendor_create_date`) VALUES 
 (1,'Ravi Enterprises','Mumbai','Mumbai','Maharshtra','400001','2000001','admin@ravienterprise.com',1,'2009-03-01'),
 (2,'Computech','New Delhi 1','New Delhi','Delhi','100001','2111190','sales@comuptechindia.com',1,'2009-03-01'),
 (3,'SHREE GANESH SUPPLIER','SHREE GANESH SUPPLIER','KOL','WB','70000134','1','',1,'2009-03-14'),
 (4,'APPLE COMPUTER','BANGALORE','BANGALORE','','','505263366','',1,'2009-03-14'),
 (5,'Atanu Maity','Atanu Maity','Thane','Maharashtra','401107','9999999999','ajprofessionals@gmail.com',1,'2013-07-21');



