<?php
include 'include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();
	if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
	{
	
		header("location:login.php");
	}
	else
	{
		$useremail=$_SESSION['useremail'];
		$username=$_SESSION['username'];
		$usertype=$_SESSION['usertype'];
		$userid=$_SESSION['userid'];

	
	}
	


	$sql = "select sum((prod_price+ prod_tax)* sc_quantity) as Amount from product_master, shopping_cart 
	where prod_id=sc_product_id and sc_check_out=0 and sc_cust_id=".$userid;
	
	$result=mysql_query($sql);
	
	$total=mysql_result($result,0,"amount"); 
	
	$sql = "select * from customer_master where cust_id=".$userid;
	$result=mysql_query($sql);

	
	$address=mysql_result($result,0,"cust_address"); 
	$city=mysql_result($result,0,"cust_city");
	$state=mysql_result($result,0,"cust_state");
	$pin=mysql_result($result,0,"cust_postal_code");
	$contact=mysql_result($result,0,"cust_contact_no");
	

if($_POST['BtnSubmit']=='Submit')
{
	ob_start();
	session_start();
	
	$userid=$_SESSION['userid'];

	$sql = "select max(checkout_id)+1 m from checkout_master ";
	$result=mysql_query($sql);
	$cmid=mysql_result($result,0,"m"); 
	
	$_SESSION['usertype']= $cmid;

	
	$sql = "select max(ct_id)+1 m from checkout_tranasation ";
	$result=mysql_query($sql);
	$ctid=mysql_result($result,0,"m"); 
	
	$sql = "insert into checkout_master values ($cmid,$userid,now(),$total,1,$ctid) ";
	$result=mysql_query($sql) or die(mysql_error());


	$sql = "select sc_id,sc_product_id,sc_quantity,(prod_price + prod_tax) as price from shopping_cart,product_master  
    where  sc_product_id=prod_id and sc_cust_id=".$userid." and sc_check_out=0";
	$result=mysql_query($sql);

	$count=mysql_num_rows($result);
	
	 	
	if ($count>0)
	{
		$i=0;
		$j='';
		for($i=0;$i<$count; $i++)
		{
			$pid=mysql_result($result,$i,"sc_product_id");
			$pqty=mysql_result($result,$i,"sc_quantity");
			$price=mysql_result($result,$i,"price");

			

			
			$ctid = $ctid +1;
		}
	}
	
	$sql = "insert into checkout_tranasation (ct_id,ct_checkout_id,ct_product_id,ct_quantity,ct_rate) values ($ctid,$cmid,$pid,$pqty,$price);";
	$result=mysql_query($sql) or die(mysql_error());
	
	 
	$sql = "update shopping_cart set sc_check_out=1 where   sc_cust_id=".$userid;
	//echo($sql);
	$result=mysql_query($sql) or die(mysql_error());

	header("Location:confirmation.php");
	//ob_end_flush();


}


?>


<html>
<head>
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - Add product to cart</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
    
    <script language="JavaScript" type="text/javascript">

	function validateForm(theForm) 
	{

	    if (document.form1.TxtCardNo.value.length != 16) 
	    {
	    	alert("Card no must be 16 character." );
	    	document.form1.TxtCardNo.focus();
	    	return false;
	    } 	    
	     
	    
	    if (isNaN(parseFloat(document.form1.TxtCardNo.value)) == true) 
	    {
	    	alert("Enter number in card no." );
	    	document.form1.TxtCardNo.focus();
	    	return false;
	    } 
	    
	    
	    if (document.form1.TxtCsv.value.length != 3) 
	    {
	    	alert("CSV no must be 3 character." );
	    	document.form1.TxtCardNo.focus();
	    	return false;
	    } 	    
	     
	    
	    if (isNaN(parseFloat(document.form1.TxtCsv.value)) == true) 
	    {
	    	alert("Enter number in CSV no." );
	    	document.form1.TxtCsv.focus();
	    	return false;
	    } 	    
	}

	</script>

</head>
<body>
    <form  name="form1"  method="post" onsubmit="return validateForm(this)" action="checkout.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="Default.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
							&nbsp;</td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<?php
								include 'categorylist.php';
								?>

						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
                    <br />
	<table border="0" width="500" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td width="46">&nbsp;</td>
			<td colspan="3" align="left">
                <strong>Confirm Payment</strong></td>
		</tr>
		<tr>
			<td width="46" style="height: 15px">&nbsp;</td>
			<td style="height: 15px; width: 161px;" align="left">
                &nbsp;Total Amount</td>
			<td style="width: 371px; height: 15px" align="left">&nbsp;<input type="text" name="TxtTotal" size="25" value="<?php echo($total); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" colspan="2">
                <strong>Shipping Details</strong></td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">
                &nbsp;Address</td>
			<td style="width: 371px" align="left">&nbsp;<input type="text" name="TxtAddress" size="25" value="<?php echo($address); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;City</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtCity" size="25" value="<?php echo($city); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;State:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtState" size="25" value="<?php echo($state); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Pin Code:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtPin" size="25" value="<?php echo($pin); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Contact No:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtContact" size="25" value="<?php echo($contact); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" colspan="2">
                



                
                </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" colspan="2">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" colspan="2">
                <strong>Payment Details</strong></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Card No</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtCardNo" size="18" value="<?php echo($cardno); ?>"  class ="TextBoxStyle" >
                CSV
                <input type="text" name="TxtCsv" size="5" value="<?php echo($csv); ?>"  class ="TextBoxStyle" ></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Card Type</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="radio" value="V2" name="Rd1" checked   >
                &nbsp;&nbsp;<img border="0" src="images/visa.gif" width="41" height="27">&nbsp;&nbsp;
                <input type="radio" value="V3" name="Rd1" >&nbsp;&nbsp;<img border="0" src="images/master.gif" width="41" height="27"> &nbsp;
</td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Expiry Date</td>
            <td align="left" style="width: 371px">
                &nbsp;Month
                						<select size="1" name="DdlMonth"   >
										<option>Jan</option>
										<option>Feb</option>
										<option>Mar</option>
										<option>Apr</option>
										<option>May</option>
										<option>Jun</option>
										<option>Jul</option>
										<option>Aug</option>
										<option>Sep</option>
										<option>Oct</option>
										<option>Nov</option>
										<option>Dec</option>
										</select>&nbsp; Year
                						<select size="1" name="DdlYear"   >

										<option selected>2020</option>
										<option>2021</option>
										<option>2022</option>
										<option>2023</option>
										<option>2024</option>
										<option>2025</option>

										</select></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle">&nbsp;&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
		<tr>
			<td width="46" style="height: 49px">&nbsp;</td>
			<td width="436" colspan="3" style="height: 49px" align="left">
                    <p>
                        &nbsp;</p>
            </td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>