<?php
				
	//get category
	$result = mysql_query("SELECT cat_id,cat_type FROM category_master order by cat_type");
	$count=mysql_num_rows($result);
				
	if ($count>0)
	{
		$i=0;
		$j='';
		for($i=0;$i<$count; $i++)
		{
			$j=$i+1;
			echo("<tr>");

				echo("<td><a href='products.php?type=c&cat=".mysql_result($result,$i,"cat_id")."'><font color='#434367'>".mysql_result($result,$i,"cat_type")."</font></a></td>");
			
			
			echo("</tr>");
		}
	}
	
?>