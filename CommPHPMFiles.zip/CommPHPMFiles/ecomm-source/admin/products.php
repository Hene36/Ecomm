<?php
include '../include.php';
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");


session_start();
if(!isset($_SESSION['adminusername']) || trim($_SESSION['adminusername'])=='')
{

	
	header("location:index.php");
}
else
{
	$adminusername=$_SESSION['adminusername'];
	$adminusertype=$_SESSION['adminusertype'];

	$adminuserid=$_SESSION['adminuserid'];
}



if ($_GET['id']!="")
{
	$productid=$_GET['id'];
	
	$sql="select prod_id, prod_description, prod_price, prod_tax, prod_name, cat_type , vendor_name from product_master, category_master,vendor_master where prod_cat_id=cat_id and prod_vendor_id = vendor_id and prod_id=$productid order by prod_id ";
	$result=mysql_query($sql);
	
	$category=mysql_result($result,0,"cat_type");
	$vender=mysql_result($result,0,"vendor_name");
	$productname=mysql_result($result,0,"prod_name");
	$description=mysql_result($result,0,"prod_description");
	$price=mysql_result($result,0,"prod_price");
	$tax=mysql_result($result,0,"prod_tax");



}
else
{


}


if($_POST['BtnSubmit']=='Submit')
{
	
	$productid=$_POST['TxtProductID'];

	$vender=$_POST['DdlVendor'];
	$category=$_POST['DdlCategory'];
	$productname=$_POST['TxtProductName'];
	$description=$_POST['TxtDescription'];
	$price=$_POST['TxtPrice'];
	$tax=$_POST['TxtTax'];



	if ($productname=="")
	{
	
		echo "<script>
		alert('Product Name Can Not Blank');
		window.location.href='products.php';

		</script>";	
	
		exit(0);
	}

	//get category id
	$sql="SELECT  cat_id FROM category_master where cat_type = '$category'" ;
	$result=mysql_query($sql);
	$cid=mysql_result($result,0,"cat_id");
	
	//get vender id
	$sql="SELECT vendor_id FROM vendor_master where vendor_name = '$vender'" ;
	$result=mysql_query($sql);
	$vid=mysql_result($result,0,"vendor_id");	
		
	
	
	if ($productid=="")
	{
			//check for duplicate user name
		$sql="SELECT count(*) as count_prod FROM product_master where prod_name='$productname'";
		$result=mysql_query($sql);
		$c=mysql_result($result,0,"count_prod ");
		
		if($c>0)
		{
			echo "<script>
			alert('Duplicate product name');
			window.location.href='products.php';

			</script>";	
		
			exit(0);
		}
		
	
		
		//get new prod id
		$sql="SELECT max(prod_id)+1 as max_id FROM product_master";
		$result=mysql_query($sql);
		$pid=mysql_result($result,0,"max_id");
		
		$sql="insert into product_master values ($pid,$cid,$vid,'$productname','$descripton',$price,$tax,$adminuserid,now(),null)"; 
		 
		 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Added successfully');
		window.location.href='products.php';
		</script>";	
	 
	}
	else
	{
		//update
		$sql="update product_master set prod_cat_id=$cid, prod_vendor_id = $vid, prod_name='$productname', prod_description='$description', prod_price=$price, prod_tax=$tax where prod_id=$productid"; 


		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Updated successfully');
		window.location.href='products.php';
		</script>";	
	
	}
	
}

?>

<html>
<head>
    <title>eCommerce Hardware Store - Products</title>
    <link href="../style/Style1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form name="form1"  method="post" action="products.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="../images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<img border="0" src="../images/logo.gif" width="289" height="82"></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right" style="text-align: left">
                                &nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
                                <a href="logout.php">Logout</a> &nbsp; <a href="changepassword.php">Change Password</a>
                                &nbsp; <a href="users.php">Users</a> &nbsp; <a href="vendors.php">Vendors</a>
                                &nbsp; <a href="products.php">Products</a>&nbsp;&nbsp; <a href="reports.php">
                                Reports</a>&nbsp; </td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;</td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22" style="height: 15px">&nbsp;</td>
							<td width="289" align="left" style="height: 15px">&nbsp;</td>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;<span style="color: #ffffff"><span id="sp_welcome" runat="server"></span></span></td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
                                <span style="font-size: 12pt; color: #ffff66"><strong>Hardware Store Admin Module -
                                    User Product</strong></span></td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<img border="0" src="../images/admin_s.gif" width="150" height="500"></td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				<div align="center">
                    <br />
	<table border="0" id="table1" cellpadding="2" cellspacing="2" style="width: 614px">
		<tr>
			<td colspan="3" align="left">
                <strong>Product Master&nbsp; </strong></td>
		</tr>
        <tr>
            <td align="left" colspan="3" style="height: 15px">
                
<table style="border-collapse: collapse" width="550" border="1">
	<tr>
		<td align="center" background=../images/menu_background.gif><b>Product Id</b></td>
		<td align="center" background=../images/menu_background.gif><b>Product Name</b></td>
		<td align="center" background=../images/menu_background.gif><b>Category</b></td>
		<td align="center" background=../images/menu_background.gif><b>Vendor</b></td>
	</tr>
	
			<?php
				
					$sql="select prod_id, prod_name, cat_type , vendor_name from product_master, category_master,vendor_master where prod_cat_id=cat_id and prod_vendor_id = vendor_id order by prod_id ";

					$result = mysql_query($sql);
					$count=mysql_num_rows($result);
				
					if ($count>0)
					{
						$i=0;
						$j='';
						for($i=0;$i<$count; $i++)
						{
							$j=$i+1;
							echo("<tr>");
			
								echo("<td><a href=products.php?id=".mysql_result($result,$i,"prod_id")."><font color='black'><u>".mysql_result($result,$i,"prod_id")."</u></font></a></td>");
								echo("<td>".mysql_result($result,$i,"prod_name")."</td>");
								echo("<td>".mysql_result($result,$i,"cat_type")."</td>");
								echo("<td>".mysql_result($result,$i,"vendor_name")."</td>");

							echo("</tr>");
						}
					}	
				?>	
	

</table>

            </td>
        </tr>
		<tr>
			<td style="height: 15px; width: 161px;" align="left">
                Product ID:</td>
			<td style="width: 371px; height: 15px" align="left">&nbsp;<input type="text" name="TxtProductID" size="30" value="<?php echo($productid); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td align="left" style="width: 161px">
                Category:</td>
			<td style="width: 371px" align="left">&nbsp;<select size="1" name="DdlCategory"   >

										<?php
											session_start();
									    $sql1="select cat_type from  category_master order by cat_type " ; 
  										$result=mysql_query($sql1) or die(mysql_error());
  										$count=mysql_num_rows($result);
											$i=0;
											for($i=0;$i<$count; $i++)
											{
												$opt=mysql_result($result,$i,"cat_type");

												if ($category==$opt)
												{
													echo("<option selected >$opt</option>");
												}
												else
												{
													echo("<option>$opt</option>");
												}

											}
											
										?>


										</select></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
                Vendor:</td>
            <td align="left" style="width: 371px">
                &nbsp;<select size="1" name="DdlVendor"   >
										<?php
											session_start();
									    $sql1="select vendor_name from  vendor_master order by vendor_name " ; 
  										$result=mysql_query($sql1) or die(mysql_error());
  										$count=mysql_num_rows($result);
											$i=0;
											for($i=0;$i<$count; $i++)
											{
												$opt=mysql_result($result,$i,"vendor_name");

												if ($vender==$opt)
												{
													echo("<option selected >$opt</option>");
												}
												else
												{
													echo("<option>$opt</option>");
												}

											}
											
										?>
										</select></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
                Product Name:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtProductName" size="30" value="<?php echo($productname); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px; height: 58px;">
                Description:</td>
			<td style="width: 371px; height: 58px;" align="left">&nbsp;<textarea rows="3" name="TxtDescription" cols="23"><?php echo($description); ?></textarea></td>
			<td width="89" style="height: 58px">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
                Price:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtPrice" size="14" value="<?php echo($price); ?>"  class ="TextBoxStyle">&nbsp;
                Tax :
                <input type="text" name="TxtTax" size="13" value="<?php echo($tax); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
                &nbsp;</td>
            <td align="left" style="width: 371px">
                &nbsp;</td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px; height: 17px;">&nbsp;</td>
			<td style="width: 371px; height: 17px;" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle">&nbsp;
                <input type="submit" value="Clear" name="BtnClear" class="ButtonStyle"></td>
			<td width="89" style="height: 17px">&nbsp;</td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>