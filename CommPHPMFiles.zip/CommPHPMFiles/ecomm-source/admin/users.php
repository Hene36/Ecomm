<?php
include '../include.php';
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");


session_start();
if(!isset($_SESSION['adminusername']) || trim($_SESSION['adminusername'])=='')
{

	
	//header("location:index.php");
}
else
{
	$adminusername=$_SESSION['adminusername'];
	$adminusertype=$_SESSION['adminusertype'];

	$adminuserid=$_SESSION['adminuserid'];
}


if ($_GET['id']!="")
{
	$userid=$_GET['id'];
	$sql="SELECT * FROM user_master WHERE user_id=$userid";
	$result=mysql_query($sql);
	
	$user_name=mysql_result($result,0,"user_name");

}
else
{


}

if($_POST['BtnClear']=='Clear')
{
	$userid="";
	$user_name="";

}

if($_POST['BtnSubmit']=='Submit')
{
	
	
	$userid=$_POST['TxtUserID'];
	$user_name=$_POST['TxtUserName'];


	if ($user_name=="")
	{
	
		echo "<script>
		alert('User Name Can Not Blank');
		window.location.href='users.php';

		</script>";	
	
		exit(0);
	}


	if ($userid=="")
	{
			//check for duplicate user name
		$sql="SELECT count(*) as count_user FROM user_master where user_name='$user_name'";
		$result=mysql_query($sql);
		$c=mysql_result($result,0,"count_user");
		
		if($c>0)
		{
			echo "<script>
			alert('Duplicate user name');
			window.location.href='users.php';

			</script>";	
		
			exit(0);
		}
		
		

		//get new user id
		$sql="SELECT max(user_id)+1 as max_id FROM user_master";
		$result=mysql_query($sql);
		$uid=mysql_result($result,0,"max_id");
		
		$sql="insert into user_master values ($uid,'$user_name','123456','admin',now())"; 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Added successfully');
		window.location.href='users.php';
		</script>";	
	
	}
	else
	{
		//update
		$sql="update user_master set user_name='$user_name' where user_id=$userid"; 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Updated successfully');
		window.location.href='users.php';
		</script>";	
	
	}
	
}

?>


<html>
<head>
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - Admin Users</title>
    <link href="../style/Style1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form name="form1" method="post" action="users.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="../images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<img border="0" src="../images/logo.gif" width="289" height="82"></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right" style="text-align: left">
                                &nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
                                <a href="logout.php">Logout</a> &nbsp; <a href="changepassword.php">Change Password</a>
                                &nbsp; <a href="users.php">Users</a> &nbsp; <a href="vendors.php">Vendors</a>
                                &nbsp; <a href="products.php">Products</a>&nbsp;&nbsp; <a href="reports.php">
                                Reports</a>&nbsp; </td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;</td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22" style="height: 15px">&nbsp;</td>
							<td width="289" align="left" style="height: 15px">&nbsp;</td>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;<span style="color: #ffffff"><span id="sp_welcome" runat="server"></span></span></td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="index.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
                                <span style="font-size: 12pt; color: #ffff66"><strong>Hardware Store Admin Module -
                                    User Master</strong></span></td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<img border="0" src="../images/admin_s.gif" width="150" height="500"></td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
                    <br />
	<table border="0" id="table1" cellpadding="2" cellspacing="2" style="width: 614px">
		<tr>
			<td colspan="3" align="left">
                <strong>Admin Users&nbsp; </strong></td>
		</tr>
        <tr>
            <td align="left" colspan="3" style="height: 15px">
            
            
            <table width="500" cellpadding="2" style="border-collapse: collapse" border="1">
				<tr>
					<td background =../images/menu_background.gif><b>User ID</b></td>
					<td background =../images/menu_background.gif><b>User Name</b></td>
					<td background =../images/menu_background.gif><b>Create Date</b></td>
				</tr>
				
				<?php
				
					$sql="select user_id,user_name, user_type, user_create_date from user_master order by user_id  ";

					$result = mysql_query($sql);
					$count=mysql_num_rows($result);
				
					if ($count>0)
					{
						$i=0;
						$j='';
						for($i=0;$i<$count; $i++)
						{
							$j=$i+1;
							echo("<tr>");
			
								echo("<td><a href=users.php?id=".mysql_result($result,$i,"user_id")."><font color='black'><u>".mysql_result($result,$i,"user_id")."</u></font></a></td>");
								echo("<td>".mysql_result($result,$i,"user_name")."</td>");
								echo("<td>".mysql_result($result,$i,"user_create_date")."</td>");
							
							echo("</tr>");
						}
					}	
				?>				
				
				
			</table>
            
            
            </td>
        </tr>
        <tr>
            <td align="left" style="height: 15px" colspan="3">
                </td>
        </tr>
		<tr>
			<td style="height: 15px; width: 161px;" align="left">
                User ID:</td>
			<td style="width: 371px; height: 15px" align="left">&nbsp;<input type="text" name="TxtUserID" size="30" value="<?php echo($userid); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td align="left" style="width: 161px">
                User Name:</td>
			<td style="width: 371px" align="left">&nbsp;<input type="text" name="TxtUserName" size="30" value="<?php echo($user_name); ?>"  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
                &nbsp;</td>
            <td align="left" style="width: 371px">
                &nbsp;</td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle">&nbsp;
                <input type="submit" value="Clear" name="BtnClear" class="ButtonStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px; height: 17px;">&nbsp;</td>
			<td style="width: 371px; height: 17px;" align="left">&nbsp;</td>
			<td width="89" style="height: 17px">&nbsp;</td>
		</tr>
		<tr>
			<td width="436" colspan="3" style="height: 49px" align="left">
                    <p>
                        &nbsp;</p>
            </td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>
