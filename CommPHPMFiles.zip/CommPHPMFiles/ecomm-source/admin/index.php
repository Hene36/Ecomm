<?php
include '../include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	
if($_POST['BtnSubmit']=='Submit')
{
	
	
	ob_start();
	session_start();


	
	// Define $myusername and $mypassword 
	$myusername=$_POST['TxtUserName']; 
	$mypassword=$_POST['TxtPassword'];
	
	// To protect MySQL injection (more detail about MySQL injection)
	$myusername = stripslashes($myusername);
	$mypassword = stripslashes($mypassword);
	$myusername = mysql_real_escape_string($myusername);
	$mypassword = mysql_real_escape_string($mypassword);
	
	$sql="SELECT * FROM user_master WHERE user_name='$myusername' and user_password='$mypassword' ";
	$result=mysql_query($sql);
	
	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);
	// If result matched $myusername and $mypassword, table row must be 1 row


	if($count==1)
	{
		
		

		$_SESSION['adminusername']= mysql_result($result,0,"user_name");  
		
		$_SESSION['adminusertype']= "admin";
		$_SESSION['adminuserid']= mysql_result($result,0,"user_id");
		session_write_close();
		header("location:users.php");
	}
	else 
	{
	
		echo "<script>
		alert('Wrong user name or password');
		//window.location.href='index.php';
		</script>";	
	
	}
	
	ob_end_flush();

}


?>



<html>
<head>
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - Admin Login</title>
    <link href="../style/Style1.css" rel="stylesheet" type="text/css" />
    
    <script language="JavaScript" type="text/javascript">

	function validateForm(theForm) 
	{
	
		 
	    if (document.form1.TxtUserName.value.length == 0) 
	    {
	    	alert("Username can't blank." );
	    	document.form1.TxtUserName.focus();
	    	return false;
	
	    } 
	    
	    if (document.form1.TxtPassword.value.length == 0) 
	    {
	    	alert("Password can't blank." );
	    	document.form1.TxtUserName.focus();
	    	return false;
	    } 
	}

</script>
</head>
<body>
    <form name="form1" onsubmit="return validateForm(this)" method="post" action="index.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="../images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<img border="0" src="../images/logo.gif" width="289" height="82"></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right" style="text-align: left">
                                &nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
                                &nbsp; </td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;</td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22" style="height: 15px">&nbsp;</td>
							<td width="289" align="left" style="height: 15px">&nbsp;</td>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;</td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.aspx">
							</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
                                <span style="font-size: 12pt; color: #ffff66"><strong>Hardware Store Admin Module</strong></span>
                            </td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<img border="0" src="../images/admin_s.gif" width="150" height="500"></td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
	<table border="0" width="500" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td width="46">&nbsp;</td>
			<td colspan="3" align="left">
                <strong>Admin User Login Here</strong></td>
		</tr>
        <tr>
            <td style="height: 15px" width="46">
            </td>
            <td align="left" style="width: 161px; height: 15px">
                </td>
            <td align="left" style="width: 371px; height: 15px">
                </td>
            <td style="height: 15px" width="89">
            </td>
        </tr>
		<tr>
			<td width="46" style="height: 15px">&nbsp;</td>
			<td style="height: 15px; width: 161px;" align="left">
                &nbsp;User Name:</td>
			<td style="width: 371px; height: 15px" align="left">&nbsp;<input type="text" name="TxtUserName" size="30" value=""  class ="TextBoxStyle"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">
                &nbsp;Password:</td>
			<td style="width: 371px" align="left">&nbsp;<input type="password" name="TxtPassword" size="30" value=""  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle">&nbsp;
                </td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
		<tr>
			<td width="46" style="height: 49px">&nbsp;</td>
			<td width="436" colspan="3" style="height: 49px" align="left">
                    <p>
                        &nbsp;</p>
            </td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>
