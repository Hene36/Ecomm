<?php
include '../include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();
	if(!isset($_SESSION['adminusername']) || trim($_SESSION['adminusername'])=='')
	{
		
		header("location:index.php");
	}
	else
	{
		
		$adminusername=$_SESSION['adminusername'];
		$adminusertype=$_SESSION['adminusertype'];
		$adminuserid=$_SESSION['adminuserid'];

	
	}
	

	
if($_POST['BtnSubmit']=='Submit')
{

	$oldpassword=$_POST['TxtOldPassword'];
	$newpassword=$_POST['TxtNewPassword'];

	// To protect MySQL injection (more detail about MySQL injection)
	$oldpassword= stripslashes($oldpassword);
	$newpassword= stripslashes($newpassword);
	$oldpassword= mysql_real_escape_string($oldpassword);
	$newpassword= mysql_real_escape_string($newpassword);
	
	$sql="SELECT * FROM user_master WHERE user_id=$adminuserid and user_password='$oldpassword' ";
	$result=mysql_query($sql);
	
	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);
	 
	if($count==1)
	{
		

		
		//update password
		$sql_execute = "update user_master set user_password='$newpassword' where user_id=$adminuserid";

		mysql_query($sql_execute) or die("Execution Failed:" . mysql_error());
		
		echo "<script>
		alert('Password Changed');
		window.location.href='index.php';
		</script>";	

	}
	else 
	{
	
		echo "<script>
		alert('Wrong Password');
		window.location.href='changepassword.php';
		</script>";	
	
	}
	
	ob_end_flush();

}


?>

<html>
<head id="Head1" runat="server">
    <title>eCommerce Hardware Store - Change Password</title>
    <link href="../style/Style1.css" rel="stylesheet" type="text/css" />
    
    <script language="JavaScript" type="text/javascript">
	document.getElementById("BtnGo").disableValidation = true;
	
	function validateForm(theForm) 
	{
    
	    
	    if (document.form1.TxtOldPassword.value.length == 0) 
	    {
	    	alert("Old password can't blank." );
	    	document.form1.TxtOldPassword.focus();
	    	return false;
	    } 
	    if (document.form1.TxtNewPassword.value.length == 0) 
	    {
	    	alert("New password can't blank." );
	    	document.form1.TxtNewPassword.focus();
	    	return false;
	    } 
	    if (document.form1.TxtConfirmPassword.value.length == 0) 
	    {
	    	alert("Confirm password can't blank." );
	    	document.form1.TxtConfirmPassword.focus();
	    	return false;
	    } 
	   	if (document.form1.TxtConfirmPassword.value != document.form1.TxtNewPassword.value ) 
	    {
	    	alert("New and Confirm password must be same." );
	    	document.form1.TxtConfirmPassword.focus();
	    	return false;
	    } 
	    
	    
	}

	</script>

    
</head>
<body>
    <form name="form1" onsubmit="return validateForm(this)" method="post" action="changepassword.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="../images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<img border="0" src="../images/logo.gif" width="289" height="82"></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right" style="text-align: left">
                                &nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
                                <a href="logout.php">Logout</a> &nbsp; <a href="changepassword.php">Change Password</a>
                                &nbsp; <a href="users.php">Users</a> &nbsp; <a href="vendors.php">Vendors</a>
                                &nbsp; <a href="products.php">Products</a>&nbsp;&nbsp; <a href="reports.php">
                                Reports</a>&nbsp; </td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;</td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22" style="height: 15px">&nbsp;</td>
							<td width="289" align="left" style="height: 15px">&nbsp;</td>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;<span style="color: #ffffff"><span id="sp_welcome" runat="server"></span></span></td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
                                <span style="font-size: 12pt; color: #ffff66"><strong> Admin Module - Change Password</strong></span></td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<img border="0" src="../images/admin_s.gif" width="150" height="500"></td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
                    <br />
	<table border="0" id="table1" cellpadding="2" cellspacing="2" style="width: 614px">
		<tr>
			<td colspan="3" align="left">
                <strong>Admin Users&nbsp; </strong></td>
		</tr>
        <tr>
            <td align="left" colspan="3" style="height: 15px">
                &nbsp;</td>
        </tr>
        <tr>
            <td align="left" style="height: 15px" colspan="3">
                </td>
        </tr>
		<tr>
			<td style="height: 15px; width: 161px;" align="left">
                User Name:</td>
			<td style="width: 371px; height: 15px" align="left">&nbsp;<input type="text" name="TxtUserName" size="36" value="<?php echo($adminusername); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td align="left" style="width: 161px">
                Old Password:</td>
			<td style="width: 371px" align="left">&nbsp;<input type="password" name="TxtOldPassword" size="25"  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
                New Password:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="password" name="TxtNewPassword" size="25"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
                Confirm Password:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="password" name="TxtConfirmPassword" size="25"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px; height: 17px;">
            </td>
            <td align="left" style="width: 371px; height: 17px;">
            </td>
            <td width="89" style="height: 17px">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px; height: 17px;">&nbsp;</td>
			<td style="width: 371px; height: 17px;" align="left">&nbsp;</td>
			<td width="89" style="height: 17px">&nbsp;</td>
		</tr>
		<tr>
			<td width="436" colspan="3" style="height: 49px" align="left">
                    <p>
                        &nbsp;</p>
            </td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>