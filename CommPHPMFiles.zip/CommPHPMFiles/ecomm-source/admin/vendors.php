<?php
include '../include.php';
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");


session_start();
if(!isset($_SESSION['adminusername']) || trim($_SESSION['adminusername'])=='')
{

	
	header("location:index.php");
}
else
{
	$adminusername=$_SESSION['adminusername'];
	$adminusertype=$_SESSION['adminusertype'];

	$adminuserid=$_SESSION['adminuserid'];
}



if ($_GET['id']!="")
{
	$venderid=$_GET['id'];
	$sql="SELECT * FROM vendor_master WHERE vendor_id=$venderid";

	$result=mysql_query($sql);
	
	$name=mysql_result($result,0,"user_name");
	$name=mysql_result($result,0,"vendor_name");
	$address=mysql_result($result,0,"vendor_address");
	$city=mysql_result($result,0,"vendor_city");
	$city=mysql_result($result,0,"vendor_city");
	$state=mysql_result($result,0,"vendor_state");
	$postalcode=mysql_result($result,0,"vendor_postal_code");
	$contactno=mysql_result($result,0,"vendor_contact_no");
	$emailid=mysql_result($result,0,"vendor_email");


}
else
{


}

if($_POST['BtnClear']=='Clear')
{
	$userid="";
	$user_name="";

}

if($_POST['BtnSubmit']=='Submit')
{
	
	
	$venderid=$_POST['TxtVendorID'];
	$name=$_POST['TxtName'];
	$address=$_POST['TxtName'];
	$city=$_POST['TxtCity'];
	$state=$_POST['TxtState'];
	$postalcode=$_POST['TxtPostalCode'];
	$contactno=$_POST['TxtContactNo'];
	$emailid=$_POST['TxtEmailId'];




	if ($name=="")
	{
	
		echo "<script>
		alert('Vender Name Can Not Blank');
		window.location.href='vendors.php';

		</script>";	
	
		exit(0);
	}


	if ($venderid=="")
	{
			//check for duplicate user name
		$sql="SELECT count(*) as count_user FROM vendor_master where vendor_name='$name'";
		$result=mysql_query($sql);
		$c=mysql_result($result,0,"count_user");
		
		if($c>0)
		{
			echo "<script>
			alert('Duplicate vender name');
			window.location.href='vendors.php';

			</script>";	
		
			exit(0);
		}
		
		

		//get new user id
		$sql="SELECT max(vendor_id)+1 as max_id FROM vendor_master";
		$result=mysql_query($sql);
		$vid=mysql_result($result,0,"max_id");
		
		$sql="insert into vendor_master values ($vid,'$name','$address','$city','$state','$postalcode','$contactno','$emailid',$adminuserid,now())"; 
		 
		 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Added successfully');
		window.location.href='vendors.php';
		</script>";	
	 
	}
	else
	{
		//update
		$sql="update vendor_master set vendor_name='$name',vendor_address='$address',vendor_city='$city',vendor_state='$state',vendor_postal_code='$postalcode',vendor_contact_no='$contactno',vendor_email='$emailid' where vendor_id=$venderid"; 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Updated successfully');
		window.location.href='vendors.php';
		</script>";	
	
	}
	
}

?>

<html>
<head>
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - Vendors</title>
    <link href="../style/Style1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form name="form1" method="post" action="vendors.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="../images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<img border="0" src="../images/logo.gif" width="289" height="82"></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right" style="text-align: left">
                                &nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
                                <a href="logout.php">Logout</a> &nbsp; <a href="changepassword.php">Change Password</a>
                                &nbsp; <a href="users.php">Users</a> &nbsp; <a href="vendors.php">Vendors</a>
                                &nbsp; <a href="products.php">Products</a>&nbsp;&nbsp; <a href="reports.php">
                                Reports</a>&nbsp; </td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;</td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22" style="height: 15px">&nbsp;</td>
							<td width="289" align="left" style="height: 15px">&nbsp;</td>
							<td width="30" style="height: 15px">&nbsp;</td>
							<td style="width: 417px; height: 15px;">&nbsp;<span style="color: #ffffff"><span id="sp_welcome" runat="server"></span></span></td>
							<td width="17" style="height: 15px">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
                                <span style="font-size: 12pt; color: #ffff66"><strong>Hardware Store Admin Module -
                                    User Vendor</strong></span></td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<img border="0" src="../images/admin_s.gif" width="150" height="500"></td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				<div align="center">
                    <br />
	<table border="0" id="table1" cellpadding="2" cellspacing="2" style="width: 614px">
		<tr>
			<td colspan="3" align="left">
                <strong>Vendor Master&nbsp; </strong></td>
		</tr>
        <tr>
            <td align="left" colspan="3" style="height: 15px">

<table style="border-collapse: collapse" width="500" border="1">
	<tr>
		<td background=../images/menu_background.gif ><b>Vender ID</b></td>
		<td background=../images/menu_background.gif><b>Vander Name</b></td>
		<td background=../images/menu_background.gif><b>Contact No</b></td>
		<td background=../images/menu_background.gif><b>Email ID</b></td>
	</tr>
	
					<?php
				
					$sql="select vendor_id,vendor_name, vendor_contact_no, vendor_email from vendor_master order by vendor_id  ";

					$result = mysql_query($sql);
					$count=mysql_num_rows($result);
				
					if ($count>0)
					{
						$i=0;
						$j='';
						for($i=0;$i<$count; $i++)
						{
							$j=$i+1;
							echo("<tr>");
			
								echo("<td><a href=vendors.php?id=".mysql_result($result,$i,"vendor_id")."><font color='black'><u>".mysql_result($result,$i,"vendor_id")."</u></font></a></td>");
								echo("<td>".mysql_result($result,$i,"vendor_name")."</td>");
								echo("<td>".mysql_result($result,$i,"vendor_contact_no")."</td>");
								echo("<td>".mysql_result($result,$i,"vendor_email")."</td>");

							echo("</tr>");
						}
					}	
				?>	
	
	
</table>
                <br />
            </td>
        </tr>
		<tr>
			<td style="height: 15px; width: 161px;" align="left">
                Vendor ID:</td>
			<td style="width: 371px; height: 15px" align="left">&nbsp;<input type="text" name="TxtVendorID" size="30" value="<?php echo($venderid); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td align="left" style="width: 161px">
                Name:</td>
			<td style="width: 371px" align="left">&nbsp;<input type="text" name="TxtName" size="30" value="<?php echo($name); ?>"  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
                Address:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtAddress" size="30" value="<?php echo($address); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
                City:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtCity" size="30" value="<?php echo($city); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px">
                State:</td>
			<td style="width: 371px" align="left">&nbsp;<input type="text" name="TxtState" size="30" value="<?php echo($state); ?>"  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td align="left" style="width: 161px">
                Postal Code:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtPostalCode" size="30" value="<?php echo($postalcode); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
                Contact No:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtContactNo" size="30" value="<?php echo($contactno); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
                Email ID:</td>
            <td align="left" style="width: 371px">
                &nbsp;<input type="text" name="TxtEmailId" size="30" value="<?php echo($emailid); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td align="left" style="width: 161px; height: 17px;">&nbsp;</td>
			<td style="width: 371px; height: 17px;" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle">&nbsp;
                <input type="submit" value="Clear" name="BtnClear" class="ButtonStyle"></td>
			<td width="89" style="height: 17px">&nbsp;</td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>