<?php
session_start();
session_unset();
session_destroy();
session_write_close();
$_SESSION['adminusername']= "";  
$_SESSION['adminusertype']= "";
$_SESSION['userid']= "";
$_SESSION['username']= "";  

$_SESSION['adminusertype']= "";
$_SESSION['adminuserid']= "";

header("location:index.php");


?>