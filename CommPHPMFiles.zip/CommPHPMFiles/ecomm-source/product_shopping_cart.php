<?php
include 'include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();
	if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
	{
		
		header("location:login.php");
	}
	else
	{
		$useremail=$_SESSION['useremail'];
		$username=$_SESSION['username'];
		$usertype=$_SESSION['usertype'];
		$userid=$_SESSION['userid'];

	
	}
	
$mode=$_GET["cat"]; 
$id=$_GET["id"]; 
	
	
if($_POST['BtnSubmit']=='Submit')
{
	$quantity=$_POST['TxtQuantity'];


	ob_start();
	
	echo($mode);
	if ($mode=='edit')
	{

	    $sql="update shopping_cart set sc_quantity=$quantity where sc_id=".$id; 
	    echo($sql);
	    
	    $result=mysql_query($sql) or die(mysql_error());

	}
	if ($mode=='add')
	{
		
		$result=mysql_query("select max(sc_id)+1 as m from shopping_cart" );
		
		$id_=mysql_result($result,0,"m"); 
		
		
	    $sql="insert into shopping_cart values($id_,$userid,now(),$id,$quantity,0)";
	    
	    $result=mysql_query($sql) or die(mysql_error());
	}
	if ($mode=='delete')
	{
	    $sql="delete from  shopping_cart  where sc_id=".$id; 
	    $result=mysql_query($sql) or die(mysql_error()); 
		 
	}


	header("Location:shoppingcart.php");
	ob_end_flush();
}
?>

<?php
$mode=$_GET["cat"]; 
$id=$_GET["id"]; 
if ($mode=='add')
{
	$result=mysql_query("select prod_id,prod_name,prod_price,prod_tax,prod_price+ prod_tax as total from product_master where prod_id=".$id );
	
	$prodid=mysql_result($result,0,"prod_id"); 
	$product=mysql_result($result,0,"prod_name"); 
	$price=mysql_result($result,0,"prod_price");
	$tax=mysql_result($result,0,"prod_tax");
	$total=mysql_result($result,0,"total");
	$quantity=0;

}


if ($mode=='edit')
{
	
	
	$str1 = "select prod_id, prod_name, prod_price, prod_tax, prod_price+ prod_tax as total, sc_quantity from product_master, shopping_cart  
	where prod_id=sc_product_id and sc_id=".$id;

	 

	$result=mysql_query($str1);
	
	$prodid=mysql_result($result,0,"prod_id"); 
	$product=mysql_result($result,0,"prod_name"); 
	$price=mysql_result($result,0,"prod_price");
	$tax=mysql_result($result,0,"prod_tax");
	$total=mysql_result($result,0,"total");
	$quantity=mysql_result($result,0,"sc_quantity");


}
if ($mode=='delete')
{
    $sql="delete from  shopping_cart  where sc_id=".$id; 
    $result=mysql_query($sql) or die(mysql_error()); 
	header("Location:shoppingcart.php");
	ob_end_flush();
}
?>

<html>
<head>
        <title>eCommerce Hardware Store - Add product to cart</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
    
<script language="JavaScript" type="text/javascript">

	function validateForm(theForm) 
	{
	    
	    if (document.form1.TxtQuantity.value == 0) 
	    {
	    	alert("Quantity can't be zero." );
	    	document.form1.TxtQuantity.focus();
	    	return false;
	    } 
	    if (document.form1.TxtQuantity.value.length == 0) 
	    {
	    	alert("Quantity can't be blank." );
	    	document.form1.TxtQuantity.focus();
	    	return false;
	    } 	    
	     
	    
	    if (isNaN(parseFloat(document.form1.TxtQuantity.value)) == true) 
	    {
	    	alert("Enter number." );
	    	document.form1.TxtQuantity.focus();
	    	return false;
	    } 
	    
	}

	</script>
</head>
<body>
    <form name="form1" onsubmit="return validateForm(this)" method="post" action="product_shopping_cart.php?cat=<?php echo($mode)?>&id=<?php echo($id)?>">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="Default.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
							<font color="#FFFFFF"><b>Search</b> 
                                </font>&nbsp; </td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<?php
								include 'categorylist.php';
								?>

						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
	<table border="0" width="500" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td width="46">&nbsp;</td>
			<td colspan="3" align="left">
                <strong>Add product to cart</strong></td>
		</tr>
        <tr>
            <td style="height: 15px" width="46">
            </td>
            <td align="left" style="width: 161px; height: 15px">
                </td>
            <td align="left" style="width: 371px; height: 15px">
                </td>
            <td style="height: 15px" width="89">
            </td>
        </tr>
		<tr>
			<td width="46" style="height: 15px">&nbsp;</td>
			<td style="height: 15px; width: 161px;" align="left">
                &nbsp;Product ID:</td>
			<td style="width: 371px; height: 15px" align="left"><input type="text" name="TxtProdId" size="25" value="<?php echo($prodid); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">
                &nbsp;Product:</td>
			<td style="width: 371px" align="left">
			<input type="text" name="TxtProduct" size="25" value="<?php echo($product); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Price:</td>
            <td align="left" style="width: 371px">
                <input type="text" name="TxtPrice" size="25" value="<?php echo($price); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Tax:</td>
            <td align="left" style="width: 371px">
                <input type="text" name="TxtTax" size="25" value="<?php echo($tax); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Total:</td>
            <td align="left" style="width: 371px">
                <input type="text" name="TxtTotal" size="25" value="<?php echo($total); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
                &nbsp;Quantity</td>
            <td align="left" style="width: 371px">                <input type="text" name="TxtQuantity" size="25" value="<?php echo($quantity); ?>"  class ="TextBoxStyle" ></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle">&nbsp;&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" style="width: 161px">
            </td>
            <td align="left" style="width: 371px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td align="left" style="width: 161px">&nbsp;</td>
			<td style="width: 371px" align="left">&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
		<tr>
			<td width="46" style="height: 49px">&nbsp;</td>
			<td width="436" colspan="3" style="height: 49px" align="left">
                    <p>
                        &nbsp;</p>
            </td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>
