<?php
include 'include.php';
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");


session_start();
if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
{
	
	header("location:login.php");
}
else
{
	$username=$_SESSION['username'];
	$usertype=$_SESSION['usertype'];

		$userid=$_SESSION['userid'];
}

if($_POST['BtnGo']=='Go')
{
	$stext=$_POST['TxtSearch'];
	header("location:products.php?type=s&val=$stext");

}
?>

<html>
<head>
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - My Account</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
                <script language="JavaScript" type="text/javascript">

	function validateForm(theForm) 
	{
	    if (document.form1.TxtSearch.value.length == 0) 
	    {
	    	alert("Search text can't blank." );
	    	document.form1.TxtSearch.focus();
	    	return false;
	
	    } 
	    
	}

</script>
</head>
<body>
        <form name="form1" onsubmit="return validateForm(this)" method="post" action="myaccount.php" >
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="index.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
							<font color="#FFFFFF"><b>Search </b>
                                        </font><input type="text" name="TxtSearch" size="20" class ="TextBoxSearch"> 
							            </font><input type="submit" value="Go" name="BtnGo" class="ButtonStyleSearch"> 

                                        </font></td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="index.php">
							Home</a> <span style="color: #ffffff">&gt; My Account</span></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<?php
								include 'categorylist.php';
								?>
						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
	<table border="0" width="100%" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td colspan="3" align="left">
                     
			<?php
			echo("Welcome <b>".$username."</b><br>");
			?>
                    
                    <br />
                    * <a href="register.php"><span style="color: #003399; text-decoration: underline">Edit Your Profile</span></a> &nbsp;&nbsp; * <a href="changepassword.php"><span style="color: #003399;
                        text-decoration: underline">Change Password</span></a> &nbsp;&nbsp; * <a href="logout.php">
                            <span style="color: #003399; text-decoration: underline">Logout</span></a></td>
		</tr>
		<tr>
			<td style="height: 15px; width: 6px;">&nbsp;</td>
			<td width="103" style="height: 15px" align="left">
                </td>
			<td style="width: 278px; height: 15px" align="left"></td>
			<td width="89" style="height: 15px"></td>
		</tr>
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td align="left" colspan="3">
			<span id="sp_tran">Transaction as on<strong> 07/12/13 1:01:46 AM.</strong></span></td>
		</tr>
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td align="left" colspan="3">

            	<table style="border-collapse: collapse" border="1" width="500">
				<tr>
					<td align="center" background="images/menu_background.gif"><b>Tran ID</b></td>
					<td align="center" background="images/menu_background.gif"><b>
					Tarn Date</b></td>
					<td align="center" background="images/menu_background.gif"><b>Amount</b></td>
					<td align="center" background="images/menu_background.gif"><b>Payment ID</b></td>
				</tr>
				
				
				<?php
				
					$sql="select checkout_id as TranID,checkout_date as trdate,checkout_amount as Amount,checout_transaction_id as payid from checkout_master where checkout_cust_id= ".$userid;

					$result = mysql_query($sql);
					$count=mysql_num_rows($result);
				
					if ($count>0)
					{
						$i=0;
						$j='';
						for($i=0;$i<$count; $i++)
						{
							$j=$i+1;
							echo("<tr>");
			
							
								
								echo("<td>".$j."</td>");
								echo("<td>".mysql_result($result,$i,"trdate")."</td>");
								echo("<td>".mysql_result($result,$i,"Amount")."</td>");
								echo("<td>".mysql_result($result,$i,"payid")."</td>");
								
							
							
							echo("</tr>");
						}
					}	
				?>
				
				
				

				
				
			</table>            
            </td>
		</tr>
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td width="103" align="left">&nbsp;</td>
			<td style="width: 278px" align="left">&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
   </form>
</body>
</html>
