<?php
include 'include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();
	if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
	{
		
		header("location:login.php");
	}
	else
	{
		$useremail=$_SESSION['useremail'];
		$username=$_SESSION['username'];
		$usertype=$_SESSION['usertype'];
		$userid=$_SESSION['userid'];

	
	}
	
if($_POST['BtnGo']=='Go')
{
	$stext=$_POST['TxtSearch'];
	header("location:products.php?type=s&val=$stext");

}	
	
if($_POST['BtnSubmit']=='Submit')
{

	$oldpassword=$_POST['TxtOldPassword'];
	$newpassword=$_POST['TxtNewPassword'];

	// To protect MySQL injection (more detail about MySQL injection)
	$oldpassword= stripslashes($oldpassword);
	$newpassword= stripslashes($newpassword);
	$oldpassword= mysql_real_escape_string($oldpassword);
	$newpassword= mysql_real_escape_string($newpassword);
	
	$sql="SELECT * FROM customer_master WHERE cust_id=$userid and cust_password='$oldpassword' ";
	$result=mysql_query($sql);
	
	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);
	 
	if($count==1)
	{
		

		
		//update password
		$sql_execute = "update customer_master set cust_password='$newpassword' where cust_id=$userid";

		mysql_query($sql_execute) or die("Execution Failed:" . mysql_error());
		
		echo "<script>
		alert('Password Changed');
		window.location.href='login.php';
		</script>";	

	}
	else 
	{
	
			$msg = urlencode("Invalid Login. Please try again with correct old password. ");
			header("Location:changepassword.php?msg=$msg");
	
	}
	
	ob_end_flush();

}


?>

<html>
<head id="Head1" runat="server">
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - Change Password</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
    
    <script language="JavaScript" type="text/javascript">
	document.getElementById("BtnGo").disableValidation = true;
	
	function validateForm(theForm) 
	{
    
	    
	    if (document.form1.TxtOldPassword.value.length == 0) 
	    {
	    	alert("Old password can't blank." );
	    	document.form1.TxtOldPassword.focus();
	    	return false;
	    } 
	    if (document.form1.TxtNewPassword.value.length == 0) 
	    {
	    	alert("New password can't blank." );
	    	document.form1.TxtNewPassword.focus();
	    	return false;
	    } 
	    if (document.form1.TxtConfirmPassword.value.length == 0) 
	    {
	    	alert("Confirm password can't blank." );
	    	document.form1.TxtConfirmPassword.focus();
	    	return false;
	    } 
	   	if (document.form1.TxtConfirmPassword.value != document.form1.TxtNewPassword.value ) 
	    {
	    	alert("New and Confirm password must be same." );
	    	document.form1.TxtConfirmPassword.focus();
	    	return false;
	    } 
	    
	    
	}

	</script>
</head>
<body>
    <form name="form1" onsubmit="return validateForm(this)" method="post" action="changepassword.php" >
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="index.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
</td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="index.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<span id="sp_cat" runat ="server"  ></span>

						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
                    <br />
                    <br />
                                        				  <?php
	  /******************** ERROR MESSAGES*************************************************
	  This code is to show error messages 
	  **************************************************************************/
      if (isset($_GET['msg'])) {
	  $msg =$_GET['msg'];// mysql_real_escape_string($_GET['msg']);
	  echo "<div class=\"msg\"><p class='Errortext'>$msg</p></div>";
	  }
	  /******************************* END ********************************/
			?>                    <br />
                    <br />
                    <br />
	<table border="0" width="500" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td width="46">&nbsp;</td>
			<td colspan="3" align="left">
                <strong>Change Password</strong></td>
		</tr>
		<tr>
			<td width="46" style="height: 15px">&nbsp;</td>
			<td width="103" style="height: 15px" align="left">
                &nbsp;Email ID:</td>
			<td style="width: 278px; height: 15px" align="left"><input type="text" name="TxtEmailID" size="25" value="<?php echo($useremail); ?>"  class ="TextBoxStyle"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td width="103" align="left">
                &nbsp;Old Password:</td>
			<td style="width: 278px" align="left"><input type="password" name="TxtOldPassword" size="25"  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;New Password:</td>
            <td align="left" style="width: 278px">
                <input type="password" name="TxtNewPassword" size="25"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;Confirm:</td>
            <td align="left" style="width: 278px">
                <input type="password" name="TxtConfirmPassword" size="25"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
            </td>
            <td align="left" style="width: 278px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td width="103" align="left">&nbsp;</td>
			<td style="width: 278px" align="left"><input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td width="103" align="left">&nbsp;</td>
			<td style="width: 278px" align="left">&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
		<tr>
			<td width="46" style="height: 49px">&nbsp;</td>
			<td width="436" colspan="3" style="height: 49px" align="left">
                    <p style="text-align: left">
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Old Customer
                        Click here to <a href="login.php"><span style="color: #003399; text-decoration: underline">
                            <strong>Login</strong></span></a>&nbsp;<a href="register.aspx"><span style="color: #003399; text-decoration: underline"></span></a></p>
            </td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>
