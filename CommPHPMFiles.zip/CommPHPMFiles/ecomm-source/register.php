<?php
include 'include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();
	if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
	{
	
		
		//header("location:login.php");
		
			}
	else
	{
	
		$custid=$_SESSION['userid'];
		$sql="SELECT * FROM customer_master WHERE cust_id=$custid";
		$result=mysql_query($sql);

		$useremail=mysql_result($result,0,"cust_email_id");
		
		$custpassword=mysql_result($result,0,"cust_password");
		
		$confirmpassword=mysql_result($result,0,"cust_password");
		
		$displayname=mysql_result($result,0,"cust_name");
		
		$address=mysql_result($result,0,"cust_address");
		
		$city=mysql_result($result,0,"cust_city");
		
		$state=mysql_result($result,0,"cust_state");
	
		$pincode=mysql_result($result,0,"cust_postal_code");
		
		$contactno=mysql_result($result,0,"cust_contact_no");
		

		
	
	}
	
	
	
if($_POST['BtnSubmit']=='Submit')
{

	
	$custid=$_POST['TxtCustID'];
	
	$useremail=$_POST['TxtEmailID'];
	
	$custpassword=$_POST['TxtPassword'];
	
	$displayname=$_POST['TxtDisplayName'];
	
	$address=$_POST['TxtAddress'];
	
	$city=$_POST['TxtCity'];
	
	$state=$_POST['TxtState'];

	$pincode=$_POST['TxtPinCode'];
	
	$contactno=$_POST['TxtContactNo'];
	
	if ($custid=="")
	{
		//insert
		
		//check for duplicate email id
		$sql="SELECT count(*) as count_email FROM customer_master where cust_email_id='$useremail'";
		$result=mysql_query($sql);
		$c=mysql_result($result,0,"count_email");
		
		if($c>0)
		{
			echo "<script>
			alert('Duplicate email id');
			window.location.href='register.php';

			</script>";	
		
			exit(0);
		}
		
		//get new cust id
		$sql="SELECT max(cust_id)+1 as max_id FROM customer_master";
		$result=mysql_query($sql);
		$custid=mysql_result($result,0,"max_id");
		
		$sql="insert into customer_master values ($custid,'$useremail','$custpassword','$displayname',now(),null,null,null,'$address','$city','$state','$pincode','$contactno')"; 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Registered successfully');
		window.location.href='login.php';
		</script>";	
	}
	
	else
	
	{
		//update
		$sql="update customer_master set cust_name='$displayname',cust_address='$address',cust_city='$city',cust_state='$state',cust_postal_code='$pincode',cust_contact_no='$contactno' where cust_id=$custid"; 
		$result=mysql_query($sql) or die(mysql_error());
		
				
		echo "<script>
		alert('Updated successfully');
		window.location.href='myaccount.php';
		</script>";	

	
	
	
	}
	
}


?>
<html>
<head id="Head1">
    <title>eCommerce Hardware Store - New Customer Registration</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
    
    
        <script language="JavaScript" type="text/javascript">

	function validateForm(theForm) 
	{
	    
	    if (document.form1.TxtEmailID.value.length == 0) 
	    {
	    	alert("Email id can not blank." );
	    	document.form1.TxtEmailID.focus();
	    	return false;
	    } 
	    
		var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
		
		  if(!document.form1.TxtEmailID.value.match(reEmail)) {
		    alert("Invalid email address");
		    document.form1.TxtEmailID.focus();
		    return false;
		  }
	    
	    if (document.form1.TxtPassword.value.length == 0) 
	    {
	    	alert("Password can't blank." );
	    	document.form1.TxtPassword.focus();
	    	return false;
	    } 
	    if (document.form1.TxtConfirmPassword.value.length == 0) 
	    {
	    	alert("Confirm password can't blank." );
	    	document.form1.TxtConfirmPassword.focus();
	    	return false;
	    } 
	   	if (document.form1.TxtConfirmPassword.value != document.form1.TxtPassword.value ) 
	    {
	    	alert("New and Confirm password must be same." );
	    	document.form1.TxtConfirmPassword.focus();
	    	return false;
	    } 
	    if (document.form1.TxtDisplayName.value.length == 0) 
	    {
	    	alert("Display name can't blank." );
	    	document.form1.TxtDisplayName.focus();
	    	return false;
	    } 
	    
	}

	</script>
</head>
<body>
    <form  name="form1" onsubmit="return validateForm(this)" method="post" action="register.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="Default.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
							&nbsp;</td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<?php
								include 'categorylist.php';
								?>
						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				<!-- products --->
				
				 <br />
				<div align="center">
                    <br />
                    <br />
                    <br />
	<table border="0" width="500" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td width="46">&nbsp;</td>
			<td colspan="3" align="left">
                <strong>Customer Registration</strong></td>
		</tr>
        <tr>
            <td style="height: 15px" width="46">
            </td>
            <td align="left" style="height: 15px" width="103">
                &nbsp;Customer ID:</td>
            <td align="left" style="width: 278px; height: 15px">
<input type="text" name="TxtCustID" size="30" value="<?php echo($custid); ?>"  class ="TextBoxStyleReadOnly" readonly ="true"></td>
            <td style="height: 15px" width="89">
            </td>
        </tr>
		<tr>
			<td width="46" style="height: 15px">&nbsp;</td>
			<td width="103" style="height: 15px" align="left">
                &nbsp;Email ID:</td>
			<td style="width: 278px; height: 15px" align="left"><input type="text" name="TxtEmailID" size="30" value="<?php echo($useremail); ?>"  class ="TextBoxStyle"></td>
			<td width="89" style="height: 15px">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;Password :</td>
            <td align="left" style="width: 278px">
<input type="password" name="TxtPassword" size="30" value="<?php echo($custpassword); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;Confirm :</td>
            <td align="left" style="width: 278px">
<input type="password" name="TxtConfirmPassword" size="30" value="<?php echo($confirmpassword); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td width="103" align="left">
                &nbsp;Display Name</td>
			<td style="width: 278px" align="left">
<input type="text" name="TxtDisplayName" size="30" value="<?php echo($displayname); ?>"  class ="TextBoxStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
            </td>
            <td align="left" style="width: 278px">
            </td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" colspan="2">
                <strong>Shipping Details</strong></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;Address:</td>
            <td align="left" style="width: 278px">
<input type="text" name="TxtAddress" size="30" value="<?php echo($address); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;City:</td>
            <td align="left" style="width: 278px">
<input type="text" name="TxtCity" size="30" value="<?php echo($city); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;State:</td>
            <td align="left" style="width: 278px">
<input type="text" name="TxtState" size="30" value="<?php echo($state); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;Pin Code:</td>
            <td align="left" style="width: 278px">
<input type="text" name="TxtPinCode" size="30" value="<?php echo($pincode); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
                &nbsp;Contact No:</td>
            <td align="left" style="width: 278px">
<input type="text" name="TxtContactNo" size="30" value="<?php echo($contactno); ?>"  class ="TextBoxStyle"></td>
            <td width="89">
            </td>
        </tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
            </td>
            <td align="left" style="width: 278px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td width="103" align="left">&nbsp;</td>
			<td style="width: 278px" align="left">&nbsp;<input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
        <tr>
            <td width="46">
            </td>
            <td align="left" width="103">
            </td>
            <td align="left" style="width: 278px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td width="46">&nbsp;</td>
			<td width="103" align="left">&nbsp;</td>
			<td style="width: 278px" align="left">&nbsp;</td>
			<td width="89">&nbsp;</td>
		</tr>
		<tr>
			<td width="46" style="height: 10px">&nbsp;</td>
			<td width="436" colspan="3" style="height: 10px" align="left">
                    <p>
                        Already Registered click here to <a href="login.php"><span style="color: #003399;
                            text-decoration: underline"><strong>Login</strong></span></a></p>
            </td>
		</tr>
	</table>
</div>
                    <br />
                    <br />
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>
