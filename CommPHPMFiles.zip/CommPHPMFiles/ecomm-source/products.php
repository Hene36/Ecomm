<?php
include 'include.php';
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

session_start();
if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
{
	//header("location:index.php");
}
else
{
	$username=$_SESSION['username'];
	$usertype=$_SESSION['usertype'];

}
if($_POST['BtnGo']=='Go')
{
	$stext=$_POST['TxtSearch'];
	header("location:products.php?type=s&val=$stext");
}
?>
<html>


    <head>


    <title>eCommerce Hardware Store - Products</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
            <script language="JavaScript" type="text/javascript">

	function validateForm(theForm) 
	{
	    if (document.form1.TxtSearch.value.length == 0) 
	    {
	    	alert("Search text can't blank." );
	    	document.form1.TxtSearch.focus();
	    	return false;
	
	    } 
	    
	}

</script>
    
</head>
	 

<body>
    <form name="form1" onsubmit="return validateForm(this)" method="post" action="products.php" >

    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="index.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php?type=a">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
							<font color="#FFFFFF"><b>Search </b>
                                        </font><input type="text" name="TxtSearch" size="20" class ="TextBoxSearch"> 
							            </font><input type="submit" value="Go" name="BtnGo" class="ButtonStyleSearch"> 

                                        </font></td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="index.php">
							Home</a> <span style="color: #ffffff">&gt;</span> <a href="products.php">Products</a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<?php
								include 'categorylist.php';
								?>

						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				<!-- products --->
				
				 <br />
				 
				 <?php
				 include 'productlist.php';
				 ?>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
   </form>
</body>
</html>
