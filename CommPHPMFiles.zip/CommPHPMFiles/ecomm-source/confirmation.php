<?php
include 'include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();

if($_POST['BtnSubmit']=='Submit')
{
header("Location:myaccount.php");
}
?>

<html>
<head>
    <title>Transcation Successful</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form id="form1" method="post" action="confirmation.php">
<div align="center">
    <br />
    <br />
<br />
	<table border="1" width="60%" style="border-collapse: collapse" bordercolor="#FF0000" id="table1">
		<tr>
			<td>
			<p align="center">
                <br />
                Your Transaction is successful</p>
			<p align="center">Transaction ID is : <b>
			<?php
				session_start();
				echo($_SESSION['usertype']);
			
			?>
			
			
			</b></p>
			<p align="center">
                
                
                <input type="submit" value="Submit" name="BtnSubmit" class="ButtonStyle"><br />
                &nbsp;</td>
		</tr>
	</table>
</div>
    </form>
</body>
</html>