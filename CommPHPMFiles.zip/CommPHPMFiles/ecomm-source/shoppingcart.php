<?php
include 'include.php';
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	ob_start();
	session_start();
	if(!isset($_SESSION['username']) || trim($_SESSION['username'])=='')
	{
	
		header("location:login.php");
	}
	else
	{
		$useremail=$_SESSION['useremail'];
		$username=$_SESSION['username'];
		$usertype=$_SESSION['usertype'];
		$userid=$_SESSION['userid'];

	
	}
	
if($_POST['BtnGo']=='Go')
{
	$stext=$_POST['TxtSearch'];
	header("location:products.php?type=s&val=$stext");

}	
	
if($_POST['BtnCheckOut']=='Check Out')
{
	header("Location:checkout.php");
	ob_end_flush();
}

if($_POST['BtnAddProduct']=='Add Product')
{
	header("Location:products.php");
	ob_end_flush();
}

?>
<html>
<head>
    <meta http-equiv="Content-Language" content="en-us">
    <title>eCommerce Hardware Store - My Account</title>
    <link href="style/Style1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form name="form1"  method="post" action="shoppingcart.php">
    <div>
    
    <div align="center">
    	<table border="1" width="800" cellspacing="0" cellpadding="0" style="border-collapse: collapse" id="table3" bordercolor="#434367">
			<tr>
				<td align="left" valign="top">
		<table border="0" width="800" cellspacing="0" id="table4" height="548">
			<tr>
				<td background="images/header_background.gif" height="133" align="left" valign="top" width="796" colspan="2">
				<div align="left">
					<table border="0" width="796" id="table5" cellspacing="0">
						<tr>
							<td width="311" rowspan="5" colspan="2" align="left" valign="top">
							<a href="Default.php">
							<img border="0" src="images/logo.gif" width="289" height="82"></a></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">
							<p align="right"><a href="products.php">Products</a>&nbsp;&nbsp;
							<a href="myaccount.php">My Account</a>&nbsp;&nbsp;
							<a href="shoppingcart.php">Shopping Cart</a>&nbsp;&nbsp;
							<a href="aboutus.php">About Us</a>&nbsp;&nbsp;
							<a href="contactus.php">Contact Us</a> </td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="30" >&nbsp;</td>
							<td valign="top" style="text-align: right">
							<font color="#FFFFFF"><b>Search </b>
                                        </font><input type="text" name="TxtSearch" size="20" class ="TextBoxSearch"> 
							            </font><input type="submit" value="Go" name="BtnGo" class="ButtonStyleSearch"> 

                                        </font></td>
							<td width="17" >&nbsp;</td>
						</tr>
						<tr>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left">&nbsp;</td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
						<tr>
							<td width="22">&nbsp;</td>
							<td width="289" align="left"><a href="Default.php">
							Home</a> <span style="color: #ffffff">&gt; Shopping Cart</span></td>
							<td width="30">&nbsp;</td>
							<td style="width: 417px">&nbsp;</td>
							<td width="17">&nbsp;</td>
						</tr>
					</table>
				</div>
				</td>
			</tr>
			<tr>
				<td width="135" align="left" valign="top" rowspan="2" style="border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-width: 1px; border-bottom-width: 1px">
				<table border="0" width="135" bordercolor="#434367" id="table6" height="399">
					<tr>
						<td width="131" align="left" valign="top" height="399">
						<table border="0" width="130" cellspacing="0" id="table7" cellpadding="2">
							<tr>
								<td background="images/menu_background.gif" width="126" style="height: 16px">
								<p align="center"><b><font color="#FFFFFF">Category</font></b></td>
							</tr>
							
								
								<?php
								include 'categorylist.php';
								?>

						</table>
						</td>
					</tr>
				</table>
				</td>
				<td  align="left" valign="top" height="396" style=" padding-left:5pt; padding-top :5pt;"> 
				
				 
				
				 <br />
				<div align="center">
	<table border="0" width="100%" id="table1" cellpadding="2" cellspacing="2">
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td colspan="3" align="left">
                    <span id="sp_welcome" runat ="server" >
                    <?php echo($username);?>, your 
					cart</span></td>
		</tr>
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td align="left" colspan="3">
			<span id="sp_tran" runat ="server" ></span></td>
		</tr>
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td align="left" colspan="3">
                
                <!-- cart details -->
   <table  border="1" cellSpacing="0" cellPadding="3" style="border-collapse: collapse" width ="600">
	<tr>
		<td background="images/menu_background.gif">&nbsp;</td>
		<td background="images/menu_background.gif"><b>Product</b></td>
		<td background="images/menu_background.gif"><b>Price</b></td>
		<td background="images/menu_background.gif"><b>Tax</b></td>
		<td background="images/menu_background.gif"><b>Qty</b></td>
		<td background="images/menu_background.gif"><b>Amount</b></td>
	</tr>
	<?php
	
		$sql="select sc_id, prod_name as Product, prod_price as Price, prod_tax as Tax, sc_quantity as Qty, (prod_price+ prod_tax)* sc_quantity as Amount from product_master, shopping_cart 
        where prod_id=sc_product_id and sc_check_out=0 and sc_cust_id= ".$userid;

		$result = mysql_query($sql);
		$count=mysql_num_rows($result);
	
		
		if ($count>0)
		{
			$i=0;
			$j='';
			for($i=0;$i<$count; $i++)
			{
				$j=$i+1;
				echo("<tr>");

				
					echo("<td>
					<a href='product_shopping_cart.php?cat=edit&id=".mysql_result($result,$i,"sc_id")."'><font color='black'><u>Edit</u></font></a> 
					&nbsp;&nbsp;
					<a href='product_shopping_cart.php?cat=delete&id=".mysql_result($result,$i,"sc_id")."'><font color='black'><u>Delete</u></font></a></td>");
					echo("<td>".mysql_result($result,$i,"Product")."</td>");
					echo("<td>".mysql_result($result,$i,"Price")."</td>");
					echo("<td>".mysql_result($result,$i,"Tax")."</td>");
					echo("<td>".mysql_result($result,$i,"Qty")."</td>");
					echo("<td>".mysql_result($result,$i,"Amount")."</td>");		
				
				
				echo("</tr>");
			}
		}	
	?>

	

	
	
	
</table>
                
            </td>
		</tr>
        <tr>
            <td style="width: 6px">
            </td>
            <td align="left" width="103">
            </td>
            <td align="left" style="width: 278px">
            </td>
            <td width="89">
            </td>
        </tr>
		<tr>
			<td style="width: 6px">&nbsp;</td>
			<td width="103" align="left">&nbsp;</td>
			<td style="width: 278px" align="left">&nbsp;<input type="submit" value="Check Out" name="BtnCheckOut" class="ButtonStyle">&nbsp;
                <input type="submit" value="Add Product" name="BtnAddProduct" class="ButtonStyle"></td>
			<td width="89">&nbsp;</td>
		</tr>
	</table>
</div>
				
				</td>
			</tr>
			<tr>
				<td width="661" height="19" align="left" valign="top" style="border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px">
				<p align="center"> 
				 � 2020, Hardware Store
				 � </td>
			</tr>
			</table>
				</td>
			</tr>
		</table>
	</div>
    
    </div>
    </form>
</body>
</html>
