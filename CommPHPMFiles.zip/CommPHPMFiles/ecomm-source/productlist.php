<?php
include 'include.php';
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
	//echo("1");
	//get product and make query
	$rows = explode("&", $_SERVER['QUERY_STRING']);
	$q1=" ";
	$lmt=" ";
	$nw=" ";

	if ($_GET['type']=="")
	{
		$q1=" ";
		$lmt=" limit 2";
		$nw= "<strong><font color='red'>NEW</font>&nbsp;&nbsp; ";
	}
	if ($_GET['type']=="c")
	{
		$q1=" and c.cat_id=".$_GET['cat'] ;
	}
	if ($_GET['type']=="a")
	{
		$q1=" ";
	}
	if ($_GET['type']=="s")
	{
		$q1=" and prod_name like '%".$_GET['val']."%' " ;
	}
	
	$str="select p.prod_id, c.cat_type, v.vendor_name, p.prod_name, p.prod_description,p.prod_price,p.prod_tax, p.prod_price+p.prod_tax as total ,p.prod_image " .
        " from product_master p,category_master c, vendor_master v " .
        " where p.prod_cat_id=c.cat_id and p.prod_vendor_id=v.vendor_id ". $q1." order by prod_id desc ". $lmt;

	//echo("2");
	$result = mysql_query($str);
	$count=mysql_num_rows($result);
					
	//echo($str);


				
	if ($count>0)
	{
		$i=0;
		$j='';
		for($i=0;$i<$count; $i++)
		{
			$j=$i+1;
			

				//echo(mysql_result($result,$i,"prod_name"));
			
			    echo("<table border='0' width='95%' id='table__" .$i."' >");
	            echo("<tr>");
		        echo("<td align='left' valign='top' colspan='2'>");
                echo("<span style='font-size: 10pt'><strong>".$nw.mysql_result($result,$i,"prod_name")."</strong></span></td>");
	            echo("</tr>");
	             
	            echo("<tr>");
		        echo("<td align='left' valign='top' style='width: 688px'>");
		        echo("<img border='0' src='prod_image/".mysql_result($result,$i,"prod_image")."'></td>");
		        echo("<td align='right' valign='top' width='306'>");
		        echo("<table border='0' id='table2_" . $i . "' align='right' style='width: 182px'>");
			    echo("<tr>");
				echo("<td style='width: 130px'>Category : </td>");
				echo("<td width='149' align='left'><b>".mysql_result($result,$i,"cat_type")."</b></td>");
			    echo("</tr>");
			    echo("<tr>");
				echo("<td style='width: 130px'>&nbsp;</td>");
				echo("<td width='149'>&nbsp;</td>");
			    echo("</tr>");
			    echo("<tr>");
				echo("<td style='width: 130px'>Price</td>");
				echo("<td width='149' align='right'>".mysql_result($result,$i,"prod_price")."</td>");
			    echo("</tr>");
			    echo("<tr>");
				echo("<td style='width: 130px'>Tax</td>");
                echo("<td width='149' align='right'>".mysql_result($result,$i,"prod_tax")."</td>");
			    echo("</tr>");
			    echo("<tr>");
				echo("<td style='width: 130px'>Total</td>");
                echo("<td width='149' style='border-left-width: 1px; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-width: 1px' align='right'>".mysql_result($result,$i,"total")."</td>");
			    echo("</tr>");
                echo("<tr>");
                echo("<td style='width: 130px'>");
                echo("</td>");
                echo("<td align='right' style='border-top: 1px solid; border-left-width: 1px; border-bottom-width: 1px; border-right-width: 1px' width='149'>");
                echo("</br><a href='product_shopping_cart.php?cat=add&id=".mysql_result($result,$i,"prod_id"). "'><span style='color: #003399; text-decoration: underline'>");
                echo("<strong>Add to Cart</strong></span></a></td>");
                echo("</tr>");
		        echo("</table>");
                
		        echo("</td>");
	            echo("</tr>");
	            echo("<tr>");
		        echo("<td align='left' valign='top'  colspan='2'><b>Description:</b><br>");
		        echo(mysql_result($result,$i,"prod_description"));
                echo("</td>");
	            echo("</tr>");
	             

                echo("</table>");
                echo("</br></br>");
			
		}
	}
	 
?>