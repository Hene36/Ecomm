<?php

	error_reporting(E_ALL ^ E_DEPRECATED);
error_reporting(E_ERROR | E_PARSE);
	$host="localhost"; // Host name 
	$username="comdb"; // Mysql username 
	$password="comdb"; // Mysql password 
	$db_name="comdb"; // Database name 
?>